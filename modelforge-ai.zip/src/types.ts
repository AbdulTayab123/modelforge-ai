export interface ColumnStats {
  mean: number;
  std: number;
  min: number;
  p25: number;
  median: number;
  p75: number;
  max: number;
  skewness: number;
  histogram: Array<{ bin_start: number; bin_end: number; count: number }>;
}

export interface ColumnProfile {
  name: string;
  dtype: string;
  inferred_type: 'numeric' | 'categorical';
  missing_count: number;
  missing_percentage: number;
  unique_count: number;
  sample_values: any[];
  stats?: ColumnStats;
  top_categories?: Array<{ category: string; count: number; percentage: number }>;
}

export interface DatasetProfile {
  total_rows: number;
  total_columns: number;
  duplicate_rows: number;
  columns: ColumnProfile[];
  correlations: Record<string, Record<string, number>>;
  warnings: string[];
  preview: Record<string, any>[];
}

export interface DatasetItem {
  id: string;
  name: string;
  filename: string;
  row_count: number;
  col_count: number;
  file_size_bytes: number;
  is_sample: boolean;
  created_at: string;
  profile?: DatasetProfile;
}

export interface FeatureImportance {
  feature: string;
  importance: number;
  percentage: number;
}

export interface ConfusionMatrixData {
  classes: string[];
  matrix: number[][];
}

export interface RocPoint {
  fpr: number;
  tpr: number;
  threshold: number;
}

export interface PrecisionRecallPoint {
  recall: number;
  precision: number;
}

export interface ThresholdMetricPoint {
  threshold: number;
  F1: number;
  ACCURACY: number;
  PRECISION: number;
  RECALL: number;
  SPECIFICITY: number;
}

export interface ActualVsPredictedPoint {
  actual: number;
  predicted: number;
  residual: number;
}

export interface ExperimentCharts {
  confusion_matrix?: ConfusionMatrixData;
  roc_curve?: RocPoint[];
  precision_recall_curve?: PrecisionRecallPoint[];
  threshold_metrics?: ThresholdMetricPoint[];
  actual_vs_predicted?: ActualVsPredictedPoint[];
}

export interface ExperimentModel {
  id: string;
  dataset_id: string;
  model_name: string;
  algorithm: string;
  task_type: 'classification' | 'regression';
  target_column: string;
  feature_columns: string[];
  hyperparameters: Record<string, any>;
  data_prep: {
    test_size: number;
    random_state: number;
    numeric_imputer: string;
    categorical_imputer: string;
    scaler: string;
    train_samples: number;
    test_samples: number;
  };
  metrics: Record<string, number | null>;
  charts: ExperimentCharts;
  feature_importances: FeatureImportance[];
  training_time_ms: number;
  is_best: number | boolean;
  is_deployed: number | boolean;
  created_at: string;
}

export interface TrainConfig {
  dataset_id: string;
  target_column: string;
  feature_columns: string[];
  task_type: 'classification' | 'regression';
  algorithm: string;
  hyperparameters?: Record<string, any>;
  test_size?: number;
  random_state?: number;
  numeric_imputer?: string;
  categorical_imputer?: string;
  scaler?: string;
  model_name?: string;
}

export interface PredictionResult {
  prediction: string | number;
  task_type: string;
  probabilities?: Array<{ class: string; probability: number }>;
  input_features: Record<string, any>;
  timestamp: string;
  prediction_id?: string;
}
