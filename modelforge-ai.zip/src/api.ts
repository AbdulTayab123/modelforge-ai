import { DatasetItem, ExperimentModel, TrainConfig, PredictionResult } from './types';

const BASE_URL = '/api';

export async function fetchHealth(): Promise<{ status: string; app: string; python: string; scikit_learn_version: string; numpy_version: string; pandas_version: string }> {
  const res = await fetch(`${BASE_URL}/health`);
  if (!res.ok) throw new Error('Failed to reach backend health endpoint');
  return res.json();
}

export async function fetchDatasets(): Promise<DatasetItem[]> {
  const res = await fetch(`${BASE_URL}/datasets`);
  if (!res.ok) throw new Error('Failed to load datasets');
  return res.json();
}

export async function fetchDatasetDetails(id: string): Promise<DatasetItem> {
  const res = await fetch(`${BASE_URL}/datasets/${id}`);
  if (!res.ok) throw new Error(`Failed to load dataset details for ${id}`);
  return res.json();
}

export async function uploadDatasetFile(file: File): Promise<DatasetItem> {
  const formData = new FormData();
  formData.append('file', file);
  const res = await fetch(`${BASE_URL}/datasets/upload`, {
    method: 'POST',
    body: formData,
  });
  if (!res.ok) {
    const errorData = await res.json().catch(() => ({ detail: 'Upload failed' }));
    throw new Error(errorData.detail || 'Failed to upload dataset');
  }
  return res.json();
}

export async function trainModel(config: TrainConfig): Promise<ExperimentModel> {
  const res = await fetch(`${BASE_URL}/train`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(config),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: 'Training failed' }));
    throw new Error(err.detail || 'Training failed');
  }
  return res.json();
}

export async function fetchExperiments(datasetId?: string): Promise<ExperimentModel[]> {
  const url = datasetId ? `${BASE_URL}/experiments?dataset_id=${encodeURIComponent(datasetId)}` : `${BASE_URL}/experiments`;
  const res = await fetch(url);
  if (!res.ok) throw new Error('Failed to load experiments');
  return res.json();
}

export async function fetchExperimentById(id: string): Promise<ExperimentModel> {
  const res = await fetch(`${BASE_URL}/experiments/${id}`);
  if (!res.ok) throw new Error(`Experiment ${id} not found`);
  return res.json();
}

export async function setBestModel(id: string): Promise<void> {
  const res = await fetch(`${BASE_URL}/experiments/${id}/set_best`, { method: 'POST' });
  if (!res.ok) throw new Error('Failed to set as best model');
}

export async function toggleModelDeployment(id: string): Promise<{ is_deployed: boolean }> {
  const res = await fetch(`${BASE_URL}/experiments/${id}/deploy`, { method: 'POST' });
  if (!res.ok) throw new Error('Failed to toggle model deployment');
  return res.json();
}

export async function predict(experimentId: string, features: Record<string, any>): Promise<PredictionResult> {
  const res = await fetch(`${BASE_URL}/predict/${experimentId}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ features }),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: 'Prediction failed' }));
    throw new Error(err.detail || 'Prediction failed');
  }
  return res.json();
}

export function getDownloadModelUrl(experimentId: string): string {
  return `${BASE_URL}/experiments/${experimentId}/download`;
}

export function getNotebookUrl(experimentId: string): string {
  return `${BASE_URL}/experiments/${experimentId}/notebook`;
}
