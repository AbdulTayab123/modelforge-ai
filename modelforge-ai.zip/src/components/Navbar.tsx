import React from 'react';
import { Layers, Bell, Settings, Menu, ChevronDown, CheckCircle2, Cpu } from 'lucide-react';

interface NavbarProps {
  currentProject?: string;
  backendInfo?: { app: string; python: string; scikit_learn_version: string } | null;
  activeStage: string;
  onSelectStage: (stage: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentProject = 'DS QA Certification 2026',
  backendInfo,
  activeStage,
  onSelectStage,
}) => {
  const stages = [
    { id: 'dataset', label: '1. Dataset' },
    { id: 'explore', label: '2. Explore' },
    { id: 'prepare', label: '3. Prepare' },
    { id: 'train', label: '4. Train' },
    { id: 'models', label: '5. Model View' },
    { id: 'compare', label: '6. Compare' },
    { id: 'predict', label: '7. Predict' },
  ];

  return (
    <header className="h-14 bg-[#0a0f18] border-b border-slate-800/80 px-4 flex items-center justify-between select-none z-30 sticky top-0">
      {/* Brand & Logo */}
      <div className="flex items-center gap-6">
        <div className="flex items-center gap-2.5 cursor-pointer" onClick={() => onSelectStage('models')}>
          <div className="w-7 h-7 rounded-md bg-gradient-to-tr from-blue-600 to-cyan-400 flex items-center justify-center text-white shadow-md shadow-blue-500/20">
            <Layers className="w-4 h-4" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-sm font-bold tracking-tight text-white font-sans">
              CorePlex<span className="text-cyan-400">ML</span>
            </span>
            <span className="text-xs text-slate-400 font-normal">
              Web Interface
            </span>
          </div>
        </div>

        {/* Guided Workflow Stage Selector */}
        <nav className="hidden lg:flex items-center gap-1 bg-slate-900/60 p-1 rounded-md border border-slate-800">
          {stages.map((stage) => {
            const isActive = activeStage === stage.id;
            return (
              <button
                key={stage.id}
                onClick={() => onSelectStage(stage.id)}
                className={`px-2.5 py-1 text-xs font-medium rounded transition-all cursor-pointer ${
                  isActive
                    ? 'bg-blue-600/90 text-white shadow-sm font-semibold'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                }`}
              >
                {stage.label}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Right Controls & Profile */}
      <div className="flex items-center gap-3">
        {/* Python & Scikit-learn status badge */}
        <div className="hidden sm:flex items-center gap-2 px-2.5 py-1 rounded-md bg-slate-900 border border-slate-800 text-xs">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
          </span>
          <span className="text-slate-400 font-mono text-[11px] flex items-center gap-1">
            <Cpu className="w-3 h-3 text-cyan-400 inline" />
            FastAPI · Scikit-Learn {backendInfo?.scikit_learn_version || '1.2'}
          </span>
        </div>

        {/* Notification Bell with '9+' badge matching screenshot */}
        <div className="relative cursor-pointer p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800/60 rounded">
          <Bell className="w-4 h-4" />
          <span className="absolute -top-0.5 -right-0.5 px-1 py-0.2 bg-red-600 text-white text-[9px] font-bold rounded-full font-mono">
            9+
          </span>
        </div>

        {/* Project Selector matching screenshot */}
        <div className="flex items-center gap-2 px-2.5 py-1 rounded bg-slate-900 border border-slate-800 text-xs text-slate-200 cursor-pointer hover:border-slate-700">
          <div className="w-5 h-5 rounded-full bg-blue-700 text-white text-[10px] font-bold flex items-center justify-center font-mono">
            DC
          </div>
          <span className="font-medium text-slate-300 text-xs">{currentProject}</span>
          <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
        </div>

        {/* Settings & Menu */}
        <button className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800/60 rounded cursor-pointer" title="Settings">
          <Settings className="w-4 h-4" />
        </button>
        <button className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800/60 rounded cursor-pointer" title="Menu">
          <Menu className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
};
