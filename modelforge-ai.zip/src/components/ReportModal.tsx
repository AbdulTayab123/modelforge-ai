import React from 'react';
import { X, Printer, Download, FileText, CheckCircle2 } from 'lucide-react';
import { ExperimentModel } from '../types';

interface ReportModalProps {
  model: ExperimentModel;
  onClose: () => void;
}

export const ReportModal: React.FC<ReportModalProps> = ({ model, onClose }) => {
  const isClassification = model.task_type === 'classification';

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-[#0f172a] border border-slate-800 rounded-xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden my-auto">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/60 print:hidden">
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-purple-400" />
            <h3 className="text-sm font-bold text-white">
              Executive Evaluation & Model Audit Report
            </h3>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={handlePrint}
              className="px-3 py-1.5 rounded bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" /> Print / Save PDF
            </button>
            <button
              onClick={onClose}
              className="p-1 text-slate-400 hover:text-white rounded hover:bg-slate-800 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Printable Report Content */}
        <div className="p-8 flex-1 overflow-y-auto bg-slate-950 font-sans text-slate-200 space-y-6 print:bg-white print:text-black">
          {/* Header block */}
          <div className="border-b border-slate-800 pb-5">
            <div className="text-xs font-mono uppercase tracking-widest text-cyan-400 print:text-blue-700">
              ModelForge AI · Empirical Verification Audit
            </div>
            <h1 className="text-2xl font-black text-white mt-1 print:text-black">
              {model.model_name}
            </h1>
            <div className="text-xs text-slate-400 mt-2 font-mono flex flex-wrap gap-4 print:text-gray-600">
              <span>Algorithm: <strong className="text-slate-200 print:text-black">{model.algorithm}</strong></span>
              <span>·</span>
              <span>Task: <strong className="text-slate-200 print:text-black">{model.task_type}</strong></span>
              <span>·</span>
              <span>Target: <strong className="text-slate-200 print:text-black">{model.target_column}</strong></span>
              <span>·</span>
              <span>Evaluated: {new Date(model.created_at).toLocaleString()}</span>
            </div>
          </div>

          {/* Executive Summary */}
          <div className="space-y-2">
            <h2 className="text-sm font-bold text-slate-100 uppercase tracking-wider print:text-black">
              1. Executive Summary & Verification
            </h2>
            <p className="text-xs text-slate-300 leading-relaxed print:text-gray-800">
              The model was fitted using Scikit-learn with an end-to-end ColumnTransformer and {model.algorithm.toUpperCase()} estimator. All data preprocessing pipelines (imputation and feature scaling) were strictly fitted on the training split to eliminate data leakage.
              {isClassification
                ? ` The classification model achieved an empirical test Accuracy of ${(Number(model.metrics['ACCURACY']) * 100).toFixed(2)}% with ROC-AUC of ${Number(model.metrics['AUC']).toFixed(4)} and weighted F1 score of ${Number(model.metrics['F1']).toFixed(4)}.`
                : ` The regression pipeline achieved an R² score of ${Number(model.metrics['R2']).toFixed(4)} with Root Mean Squared Error (RMSE) of ${Number(model.metrics['RMSE']).toFixed(4)}.`}
            </p>
          </div>

          {/* Validation Metrics Grid */}
          <div className="space-y-3">
            <h2 className="text-sm font-bold text-slate-100 uppercase tracking-wider print:text-black">
              2. Quantitative Metrics
            </h2>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono text-xs">
              {Object.entries(model.metrics)
                .filter(([_, v]) => v !== null && v !== undefined)
                .slice(0, 8)
                .map(([k, v]) => (
                  <div key={k} className="p-3 rounded bg-slate-900 border border-slate-800 print:bg-gray-100 print:border-gray-300">
                    <div className="text-[10px] text-slate-500 print:text-gray-500 uppercase">{k}</div>
                    <div className="text-sm font-bold text-cyan-300 print:text-blue-900 mt-1">
                      {typeof v === 'number' ? (v < 10 ? v.toFixed(4) : v.toFixed(2)) : String(v)}
                    </div>
                  </div>
                ))}
            </div>
          </div>

          {/* Preprocessing and Features */}
          <div className="space-y-3">
            <h2 className="text-sm font-bold text-slate-100 uppercase tracking-wider print:text-black">
              3. Data Preparation & Feature Schema
            </h2>
            <div className="p-4 rounded bg-slate-900/60 border border-slate-800 text-xs space-y-2 print:bg-gray-50 print:border-gray-300">
              <div className="grid grid-cols-2 gap-2 font-mono">
                <div><span className="text-slate-500">Test Split Ratio:</span> {(model.data_prep?.test_size ?? 0.2) * 100}%</div>
                <div><span className="text-slate-500">Random State Seed:</span> {model.data_prep?.random_state ?? 42}</div>
                <div><span className="text-slate-500">Numeric Imputer:</span> {model.data_prep?.numeric_imputer}</div>
                <div><span className="text-slate-500">Scaler:</span> {model.data_prep?.scaler}</div>
              </div>
              <div className="pt-2">
                <span className="text-slate-500 font-mono block mb-1">Feature Columns ({model.feature_columns.length}):</span>
                <div className="flex flex-wrap gap-1.5 font-mono text-[11px]">
                  {model.feature_columns.map(f => (
                    <span key={f} className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 print:bg-gray-200 print:text-black">
                      {f}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Signoff */}
          <div className="pt-6 border-t border-slate-800 flex justify-between items-center text-xs text-slate-500 font-mono print:text-gray-500">
            <div>Verified by ModelForge Automated Audit</div>
            <div>Status: VALIDATED PASS</div>
          </div>
        </div>
      </div>
    </div>
  );
};
