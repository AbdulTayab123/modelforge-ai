import React, { useState, useEffect } from 'react';
import { Sliders, Play, RefreshCw, CheckCircle2, AlertTriangle, ArrowRight, Clock, History, BarChart2 } from 'lucide-react';
import { ExperimentModel, PredictionResult, DatasetItem } from '../types';
import { predict } from '../api';

interface PredictionSandboxProps {
  model: ExperimentModel;
  dataset: DatasetItem | null;
  onNavigateToModel: (model: ExperimentModel) => void;
}

export const PredictionSandbox: React.FC<PredictionSandboxProps> = ({
  model,
  dataset,
  onNavigateToModel,
}) => {
  const [inputValues, setInputValues] = useState<Record<string, any>>({});
  const [isPredicting, setIsPredicting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [currentResult, setCurrentResult] = useState<PredictionResult | null>(null);
  const [predictionHistory, setPredictionHistory] = useState<PredictionResult[]>([]);

  // Seed default feature values based on dataset columns profile
  useEffect(() => {
    const defaults: Record<string, any> = {};
    const cols = dataset?.profile?.columns || [];

    model.feature_columns.forEach((feature) => {
      const colInfo = cols.find(c => c.name === feature);
      if (colInfo) {
        if (colInfo.inferred_type === 'numeric') {
          defaults[feature] = colInfo.stats?.median ?? colInfo.stats?.mean ?? 0;
        } else {
          defaults[feature] = colInfo.top_categories?.[0]?.category ?? colInfo.sample_values?.[0] ?? '';
        }
      } else {
        defaults[feature] = 0;
      }
    });

    setInputValues(defaults);
  }, [model, dataset]);

  const handleInputChange = (feature: string, value: any) => {
    setInputValues(prev => ({
      ...prev,
      [feature]: value
    }));
  };

  const handleRunPrediction = async () => {
    setIsPredicting(true);
    setError(null);
    try {
      const res = await predict(model.id, inputValues);
      setCurrentResult(res);
      setPredictionHistory(prev => [res, ...prev.slice(0, 19)]);
    } catch (err: any) {
      setError(err.message || 'Prediction failed.');
    } finally {
      setIsPredicting(false);
    }
  };

  const isClassification = model.task_type === 'classification';
  const cols = dataset?.profile?.columns || [];

  return (
    <div className="flex-1 bg-[#0b0f17] p-6 overflow-y-auto space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800/80 pb-4">
        <div>
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <Sliders className="w-5 h-5 text-cyan-400" />
            Live Prediction Sandbox & Inference Engine
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Test model <span className="text-cyan-300 font-mono">{model.model_name}</span> ({model.algorithm}) in real time with custom feature vectors.
          </p>
        </div>

        <button
          onClick={() => onNavigateToModel(model)}
          className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded text-xs font-medium flex items-center gap-1.5 cursor-pointer"
        >
          View Full Performance Metrics <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Dynamic Input Form */}
        <div className="lg:col-span-2 bg-[#111827]/70 border border-slate-800 rounded-lg p-5">
          <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-800">
            <div>
              <h3 className="text-xs font-semibold text-slate-200 uppercase tracking-wider">
                Feature Vector Inputs ({model.feature_columns.length} Features)
              </h3>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Inputs are dynamically validated and pre-processed through the pipeline before feeding the estimator.
              </p>
            </div>
            <button
              onClick={() => {
                // Reset to median values
                const defaults: Record<string, any> = {};
                model.feature_columns.forEach((feature) => {
                  const colInfo = cols.find(c => c.name === feature);
                  if (colInfo?.inferred_type === 'numeric') {
                    defaults[feature] = colInfo.stats?.median ?? 0;
                  } else {
                    defaults[feature] = colInfo?.top_categories?.[0]?.category ?? '';
                  }
                });
                setInputValues(defaults);
              }}
              className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white rounded text-xs font-mono cursor-pointer"
            >
              Reset to Medians
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-h-[460px] overflow-y-auto pr-1">
            {model.feature_columns.map((feature) => {
              const colInfo = cols.find(c => c.name === feature);
              const isNumeric = colInfo ? colInfo.inferred_type === 'numeric' : typeof inputValues[feature] === 'number';
              const categories = colInfo?.top_categories || [];

              return (
                <div key={feature} className="p-3 bg-slate-900/60 rounded border border-slate-800 space-y-1.5">
                  <div className="flex justify-between items-center text-xs font-mono">
                    <span className="font-semibold text-slate-200">{feature}</span>
                    <span className="text-[10px] text-slate-500">{isNumeric ? 'numeric' : 'categorical'}</span>
                  </div>

                  {isNumeric ? (
                    <div>
                      <input
                        type="number"
                        step="any"
                        value={inputValues[feature] ?? ''}
                        onChange={(e) => handleInputChange(feature, e.target.value === '' ? '' : Number(e.target.value))}
                        className="w-full bg-slate-950 border border-slate-700 text-cyan-300 font-mono text-xs rounded p-2 focus:border-cyan-500 focus:outline-none"
                      />
                      {colInfo?.stats && (
                        <div className="text-[10px] text-slate-500 font-mono mt-1 flex justify-between">
                          <span>Min: {colInfo.stats.min}</span>
                          <span>Med: {colInfo.stats.median}</span>
                          <span>Max: {colInfo.stats.max}</span>
                        </div>
                      )}
                    </div>
                  ) : (
                    <select
                      value={inputValues[feature] ?? ''}
                      onChange={(e) => handleInputChange(feature, e.target.value)}
                      className="w-full bg-slate-950 border border-slate-700 text-slate-200 font-mono text-xs rounded p-2 focus:border-cyan-500 focus:outline-none"
                    >
                      {categories.map((cat, i) => (
                        <option key={i} value={cat.category}>
                          {cat.category}
                        </option>
                      ))}
                    </select>
                  )}
                </div>
              );
            })}
          </div>

          <div className="mt-5 pt-4 border-t border-slate-800 flex items-center justify-between">
            <span className="text-xs text-slate-500 font-mono">Target: {model.target_column}</span>
            <button
              onClick={handleRunPrediction}
              disabled={isPredicting}
              className={`py-2.5 px-6 rounded text-xs font-bold uppercase tracking-wider flex items-center gap-2 shadow-lg transition-all cursor-pointer ${
                isPredicting
                  ? 'bg-blue-800 text-cyan-200 cursor-wait'
                  : 'bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white'
              }`}
            >
              {isPredicting ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" /> Inferring...
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 fill-white" /> Run Inference
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right 1 Col: Live Inference Results & Probabilities */}
        <div className="space-y-6">
          <div className="bg-[#111827]/70 border border-slate-800 rounded-lg p-5">
            <h3 className="text-xs font-semibold text-slate-200 uppercase tracking-wider mb-3">
              Inference Outcome
            </h3>

            {error && (
              <div className="p-3 rounded bg-red-950/40 border border-red-800 text-red-300 text-xs flex items-center gap-2 mb-3">
                <AlertTriangle className="w-4 h-4 shrink-0 text-red-400" />
                <span>{error}</span>
              </div>
            )}

            {currentResult ? (
              <div className="space-y-4">
                <div className="p-4 rounded-lg bg-blue-950/30 border border-blue-800/60 text-center">
                  <div className="text-[10px] text-slate-400 uppercase font-mono tracking-wider">
                    Predicted {model.target_column}
                  </div>
                  <div className="text-2xl font-black text-cyan-300 font-mono mt-1">
                    {String(currentResult.prediction)}
                  </div>
                </div>

                {/* Probability meters for classification */}
                {isClassification && currentResult.probabilities && (
                  <div className="space-y-2.5 pt-2">
                    <div className="text-xs font-medium text-slate-300 flex items-center gap-1.5">
                      <BarChart2 className="w-3.5 h-3.5 text-cyan-400" /> Class Probabilities:
                    </div>
                    {currentResult.probabilities.map((prob, i) => (
                      <div key={i} className="text-xs font-mono">
                        <div className="flex justify-between text-slate-300 mb-1">
                          <span className="font-semibold">{prob.class}</span>
                          <span className="text-cyan-400">{(prob.probability * 100).toFixed(1)}%</span>
                        </div>
                        <div className="h-2 w-full bg-slate-900 rounded-full overflow-hidden border border-slate-800">
                          <div
                            className={`h-full rounded-full transition-all duration-500 ${
                              prob.probability > 0.5 ? 'bg-gradient-to-r from-blue-500 to-cyan-400' : 'bg-slate-700'
                            }`}
                            style={{ width: `${(prob.probability * 100)}%` }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                <div className="text-[10px] text-slate-500 font-mono pt-2 border-t border-slate-800 flex justify-between">
                  <span>Timestamp: {new Date(currentResult.timestamp).toLocaleTimeString()}</span>
                  <span>ID: {currentResult.prediction_id?.slice(0, 8)}</span>
                </div>
              </div>
            ) : (
              <div className="py-12 text-center text-xs text-slate-500 italic">
                Adjust features and click "Run Inference" to compute live model predictions.
              </div>
            )}
          </div>

          {/* Session History */}
          {predictionHistory.length > 0 && (
            <div className="bg-[#111827]/70 border border-slate-800 rounded-lg p-4">
              <h4 className="text-xs font-semibold text-slate-200 uppercase tracking-wider mb-2.5 flex items-center gap-1.5">
                <History className="w-3.5 h-3.5 text-slate-400" />
                Session Prediction Log ({predictionHistory.length})
              </h4>
              <div className="space-y-1.5 max-h-48 overflow-y-auto font-mono text-[11px] pr-1">
                {predictionHistory.map((hist, idx) => (
                  <div key={idx} className="p-2 bg-slate-900/60 rounded border border-slate-800 flex justify-between items-center">
                    <span className="text-cyan-300 font-semibold truncate pr-2">
                      Result: {String(hist.prediction)}
                    </span>
                    <span className="text-slate-500 text-[10px]">
                      {new Date(hist.timestamp).toLocaleTimeString()}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
