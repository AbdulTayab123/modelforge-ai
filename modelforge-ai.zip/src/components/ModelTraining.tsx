import React, { useState } from 'react';
import { Binary, Play, RefreshCw, CheckCircle2, AlertTriangle, ArrowRight, Sliders, Cpu, Sparkles } from 'lucide-react';
import { TrainConfig, ExperimentModel } from '../types';
import { trainModel } from '../api';

interface ModelTrainingProps {
  config: Partial<TrainConfig>;
  onModelTrained: (model: ExperimentModel) => void;
  onNavigateToModel: (model: ExperimentModel) => void;
}

export const ModelTraining: React.FC<ModelTrainingProps> = ({
  config,
  onModelTrained,
  onNavigateToModel,
}) => {
  const isClassification = (config.task_type || 'classification') === 'classification';

  const [selectedAlgorithm, setSelectedAlgorithm] = useState<string>(
    config.algorithm || (isClassification ? 'gbm' : 'gbm')
  );
  const [modelName, setModelName] = useState<string>('');
  const [nEstimators, setNEstimators] = useState<number>(100);
  const [learningRate, setLearningRate] = useState<number>(0.1);
  const [maxDepth, setMaxDepth] = useState<number>(3);
  const [regC, setRegC] = useState<number>(1.0);

  const [isTraining, setIsTraining] = useState(false);
  const [trainingLogs, setTrainingLogs] = useState<string[]>([]);
  const [trainingError, setTrainingError] = useState<string | null>(null);
  const [trainedModel, setTrainedModel] = useState<ExperimentModel | null>(null);

  const classificationAlgorithms = [
    { id: 'gbm', name: 'Gradient Boosting (GBM)', desc: 'Sequentially builds trees to minimize log-loss. Top performer for tabular data.', recommended: true },
    { id: 'random_forest', name: 'Random Forest Classifier', desc: 'Ensemble of bagging decision trees with randomized feature subsets.' },
    { id: 'logistic_regression', name: 'Logistic Regression', desc: 'Linear decision boundary with L2 regularization and fast inference.' },
    { id: 'decision_tree', name: 'Decision Tree Classifier', desc: 'Single interpretable decision tree with greedy Gini impurity splits.' },
    { id: 'naive_bayes', name: 'Gaussian Naive Bayes', desc: 'Probabilistic classifier assuming feature independence.' },
  ];

  const regressionAlgorithms = [
    { id: 'gbm', name: 'Gradient Boosting Regressor (GBM)', desc: 'Gradient boosted regression trees minimizing mean squared error.', recommended: true },
    { id: 'random_forest', name: 'Random Forest Regressor', desc: 'Averages predictions of multiple deep decision trees to reduce variance.' },
    { id: 'linear_regression', name: 'Ordinary Least Squares (Linear Regression)', desc: 'Standard closed-form linear estimator minimizing residual sum of squares.' },
    { id: 'ridge', name: 'Ridge Regression (L2)', desc: 'Linear regression with Tikhonov L2 penalty to handle multicollinearity.' },
    { id: 'decision_tree', name: 'Decision Tree Regressor', desc: 'Piecewise constant model splitting on minimum squared error.' },
  ];

  const algorithms = isClassification ? classificationAlgorithms : regressionAlgorithms;

  const handleStartTraining = async () => {
    if (!config.dataset_id || !config.target_column || !config.feature_columns?.length) {
      setTrainingError('Please complete Data Preparation first.');
      return;
    }

    setIsTraining(true);
    setTrainingError(null);
    setTrainedModel(null);
    setTrainingLogs([
      `[1/5] Initializing Scikit-learn training pipeline...`,
      `[2/5] Target: "${config.target_column}" (${config.task_type}). Selected features: ${config.feature_columns.length}`,
      `[3/5] Splitting dataset with holdout ratio ${(config.test_size || 0.2) * 100}% strictly before preprocessing...`,
      `[4/5] Fitting ColumnTransformer and ${selectedAlgorithm.toUpperCase()} estimator...`,
    ]);

    try {
      const hyperparameters: Record<string, any> = {};
      if (['gbm', 'random_forest'].includes(selectedAlgorithm)) {
        hyperparameters.n_estimators = nEstimators;
        hyperparameters.max_depth = maxDepth;
      }
      if (selectedAlgorithm === 'gbm') {
        hyperparameters.learning_rate = learningRate;
      }
      if (['logistic_regression', 'ridge'].includes(selectedAlgorithm)) {
        hyperparameters.C = regC;
        hyperparameters.alpha = regC;
      }

      const generatedName = modelName.trim() || `${selectedAlgorithm.toUpperCase()}_AutoML_${Date.now().toString().slice(-6)}`;

      const trainPayload: TrainConfig = {
        dataset_id: config.dataset_id,
        target_column: config.target_column,
        feature_columns: config.feature_columns,
        task_type: config.task_type || 'classification',
        algorithm: selectedAlgorithm,
        hyperparameters,
        test_size: config.test_size || 0.2,
        random_state: config.random_state || 42,
        numeric_imputer: config.numeric_imputer || 'median',
        categorical_imputer: config.categorical_imputer || 'most_frequent',
        scaler: config.scaler || 'standard',
        model_name: generatedName,
      };

      const result = await trainModel(trainPayload);

      setTrainingLogs(prev => [
        ...prev,
        `[5/5] Model trained successfully in ${result.training_time_ms} ms! Model ID: ${result.id}`,
        `[Done] ROC-AUC: ${result.metrics['AUC'] ?? 'N/A'} · Accuracy: ${result.metrics['ACCURACY'] ?? 'N/A'} · R²: ${result.metrics['R2'] ?? 'N/A'}`
      ]);

      setTrainedModel(result);
      onModelTrained(result);
    } catch (err: any) {
      setTrainingError(err.message || 'Model training failed.');
    } finally {
      setIsTraining(false);
    }
  };

  return (
    <div className="flex-1 bg-[#0b0f17] p-6 overflow-y-auto space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800/80 pb-4">
        <div>
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <Binary className="w-5 h-5 text-blue-500" />
            Model Training & Supervised Learning Engine
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Fit real Scikit-learn pipelines with cross-validation and compute empirical validation metrics.
          </p>
        </div>

        {trainedModel && (
          <button
            onClick={() => onNavigateToModel(trainedModel)}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-xs font-semibold flex items-center gap-2 shadow-md cursor-pointer"
          >
            Inspect Model in Studio <ArrowRight className="w-4 h-4" />
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Algorithm Selection & Hyperparameters */}
        <div className="lg:col-span-2 space-y-6">
          {/* Algorithm Cards */}
          <div className="bg-[#111827]/70 border border-slate-800 rounded-lg p-5">
            <h3 className="text-xs font-semibold text-slate-200 uppercase tracking-wider mb-3">
              1. Choose Machine Learning Algorithm ({isClassification ? 'Classification' : 'Regression'})
            </h3>
            <div className="space-y-2.5">
              {algorithms.map((algo) => {
                const isSelected = selectedAlgorithm === algo.id;
                return (
                  <div
                    key={algo.id}
                    onClick={() => setSelectedAlgorithm(algo.id)}
                    className={`p-3.5 rounded-lg border transition-all cursor-pointer flex items-center justify-between ${
                      isSelected
                        ? 'bg-blue-950/40 border-blue-500 shadow-md shadow-blue-950/40'
                        : 'bg-slate-900/40 border-slate-800 hover:border-slate-700 hover:bg-slate-900'
                    }`}
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className={`text-xs font-bold font-mono ${isSelected ? 'text-cyan-300' : 'text-slate-200'}`}>
                          {algo.name}
                        </span>
                        {algo.recommended && (
                          <span className="text-[10px] px-2 py-0.2 rounded bg-amber-500/10 border border-amber-500/30 text-amber-300 font-mono font-medium">
                            Recommended
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-slate-400 mt-0.5">
                        {algo.desc}
                      </div>
                    </div>

                    <div className="w-4 h-4 rounded-full border flex items-center justify-center shrink-0 ml-3">
                      {isSelected && <span className="w-2 h-2 rounded-full bg-cyan-400" />}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Hyperparameter Settings */}
          <div className="bg-[#111827]/70 border border-slate-800 rounded-lg p-5 space-y-4">
            <h3 className="text-xs font-semibold text-slate-200 uppercase tracking-wider flex items-center gap-2">
              <Sliders className="w-4 h-4 text-slate-400" />
              2. Estimator Hyperparameters
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-mono">
              <div>
                <label className="text-slate-400 block mb-1">Model Name (Optional):</label>
                <input
                  type="text"
                  placeholder={`Auto-generated (${selectedAlgorithm.toUpperCase()}_...)`}
                  value={modelName}
                  onChange={(e) => setModelName(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 text-slate-200 rounded p-2 focus:border-cyan-500 focus:outline-none"
                />
              </div>

              {['gbm', 'random_forest'].includes(selectedAlgorithm) && (
                <div>
                  <label className="text-slate-400 block mb-1">n_estimators (Trees):</label>
                  <select
                    value={nEstimators}
                    onChange={(e) => setNEstimators(Number(e.target.value))}
                    className="w-full bg-slate-900 border border-slate-700 text-slate-200 rounded p-2 focus:border-cyan-500 focus:outline-none"
                  >
                    <option value={50}>50 Trees</option>
                    <option value={100}>100 Trees (Standard)</option>
                    <option value={200}>200 Trees (Deeper Ensemble)</option>
                  </select>
                </div>
              )}

              {selectedAlgorithm === 'gbm' && (
                <div>
                  <label className="text-slate-400 block mb-1">Learning Rate:</label>
                  <select
                    value={learningRate}
                    onChange={(e) => setLearningRate(Number(e.target.value))}
                    className="w-full bg-slate-900 border border-slate-700 text-slate-200 rounded p-2 focus:border-cyan-500 focus:outline-none"
                  >
                    <option value={0.01}>0.01 (Conservative)</option>
                    <option value={0.05}>0.05</option>
                    <option value={0.1}>0.10 (Standard)</option>
                    <option value={0.2}>0.20 (Aggressive)</option>
                  </select>
                </div>
              )}

              {['gbm', 'random_forest', 'decision_tree'].includes(selectedAlgorithm) && (
                <div>
                  <label className="text-slate-400 block mb-1">Max Depth:</label>
                  <select
                    value={maxDepth}
                    onChange={(e) => setMaxDepth(Number(e.target.value))}
                    className="w-full bg-slate-900 border border-slate-700 text-slate-200 rounded p-2 focus:border-cyan-500 focus:outline-none"
                  >
                    <option value={3}>3 (Stumps, prevents overfit)</option>
                    <option value={6}>6 (Moderate)</option>
                    <option value={10}>10 (Deep)</option>
                  </select>
                </div>
              )}

              {['logistic_regression', 'ridge'].includes(selectedAlgorithm) && (
                <div>
                  <label className="text-slate-400 block mb-1">Regularization (C / Alpha):</label>
                  <select
                    value={regC}
                    onChange={(e) => setRegC(Number(e.target.value))}
                    className="w-full bg-slate-900 border border-slate-700 text-slate-200 rounded p-2 focus:border-cyan-500 focus:outline-none"
                  >
                    <option value={0.1}>0.1 (High Regularization)</option>
                    <option value={1.0}>1.0 (Balanced Default)</option>
                    <option value={10.0}>10.0 (Low Regularization)</option>
                  </select>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right 1 Col: Execution Console & Status */}
        <div className="bg-[#111827]/70 border border-slate-800 rounded-lg p-5 flex flex-col justify-between">
          <div>
            <h3 className="text-xs font-semibold text-slate-200 uppercase tracking-wider mb-3">
              3. Execution & Live Output
            </h3>

            {/* Launch Button */}
            <button
              onClick={handleStartTraining}
              disabled={isTraining}
              className={`w-full py-3 px-4 rounded text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg transition-all cursor-pointer ${
                isTraining
                  ? 'bg-blue-800 text-cyan-200 cursor-wait'
                  : 'bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white'
              }`}
            >
              {isTraining ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" /> Fitting Pipeline...
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 fill-white" /> Start Model Training
                </>
              )}
            </button>

            {trainingError && (
              <div className="mt-4 p-3 rounded bg-red-950/40 border border-red-800 text-red-300 text-xs flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0 text-red-400" />
                <span>{trainingError}</span>
              </div>
            )}

            {/* Live Terminal Log */}
            <div className="mt-4 p-3.5 bg-slate-950 rounded border border-slate-800 font-mono text-[11px] text-slate-300 min-h-[220px] max-h-[300px] overflow-y-auto space-y-1.5">
              <div className="text-slate-600">// Scikit-learn Worker Stream</div>
              {trainingLogs.length === 0 ? (
                <div className="text-slate-600 italic">Ready to train. Press "Start Model Training" to execute.</div>
              ) : (
                trainingLogs.map((log, i) => (
                  <div key={i} className="text-cyan-400/90 leading-relaxed">
                    {log}
                  </div>
                ))
              )}
            </div>
          </div>

          {trainedModel && (
            <div className="mt-4 p-3.5 bg-emerald-950/30 border border-emerald-600/40 rounded-lg space-y-2">
              <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold">
                <CheckCircle2 className="w-4 h-4" /> Training Complete!
              </div>
              <div className="text-[11px] text-slate-300 font-mono">
                {isClassification ? (
                  <>
                    Accuracy: <span className="text-cyan-300 font-bold">{trainedModel.metrics['ACCURACY']}</span> · ROC-AUC: <span className="text-cyan-300 font-bold">{trainedModel.metrics['AUC'] ?? 'N/A'}</span>
                  </>
                ) : (
                  <>
                    R²: <span className="text-cyan-300 font-bold">{trainedModel.metrics['R2']}</span> · RMSE: <span className="text-cyan-300 font-bold">{trainedModel.metrics['RMSE']}</span>
                  </>
                )}
              </div>
              <button
                onClick={() => onNavigateToModel(trainedModel)}
                className="w-full mt-2 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-xs font-medium flex items-center justify-center gap-1.5 cursor-pointer"
              >
                Inspect Full Charts <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
