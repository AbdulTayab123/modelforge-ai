import React, { useState, useEffect } from 'react';
import { X, Copy, Download, CheckCircle2, Code } from 'lucide-react';
import { ExperimentModel } from '../types';
import { getNotebookUrl } from '../api';

interface NotebookModalProps {
  model: ExperimentModel;
  onClose: () => void;
}

export const NotebookModal: React.FC<NotebookModalProps> = ({ model, onClose }) => {
  const [code, setCode] = useState<string>('Loading reproducible script...');
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    fetch(getNotebookUrl(model.id))
      .then(res => res.text())
      .then(text => setCode(text))
      .catch(() => setCode('# Error loading script'));
  }, [model.id]);

  const copyCode = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
      <div className="bg-[#0f172a] border border-slate-800 rounded-xl w-full max-w-3xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="px-5 py-3.5 border-b border-slate-800 flex items-center justify-between bg-slate-900/60">
          <div className="flex items-center gap-2">
            <Code className="w-4 h-4 text-emerald-400" />
            <h3 className="text-sm font-bold text-white">
              Reproducible Python Script: {model.model_name}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-white rounded hover:bg-slate-800 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Code Viewer */}
        <div className="p-4 flex-1 overflow-y-auto bg-slate-950 font-mono text-xs text-cyan-300">
          <pre className="whitespace-pre-wrap leading-relaxed">{code}</pre>
        </div>

        {/* Modal Footer */}
        <div className="px-5 py-3 border-t border-slate-800 flex items-center justify-between bg-slate-900/60 text-xs">
          <span className="text-slate-400 font-mono">Compatible with Python 3.10+, Pandas, and Scikit-learn</span>
          <div className="flex items-center gap-2">
            <button
              onClick={copyCode}
              className="px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 flex items-center gap-1.5 font-medium cursor-pointer"
            >
              {copied ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              {copied ? 'Copied!' : 'Copy Code'}
            </button>
            <a
              href={getNotebookUrl(model.id)}
              download={`modelforge_${model.model_name}.py`}
              className="px-3 py-1.5 rounded bg-blue-600 hover:bg-blue-500 text-white flex items-center gap-1.5 font-medium cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              Download Script (.py)
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
