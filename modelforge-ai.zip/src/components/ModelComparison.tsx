import React, { useState } from 'react';
import { LineChart, Crown, ArrowRight, Eye, Play, Download, Sparkles, Filter } from 'lucide-react';
import { ExperimentModel } from '../types';
import { getDownloadModelUrl } from '../api';

interface ModelComparisonProps {
  models: ExperimentModel[];
  onSelectModel: (model: ExperimentModel) => void;
  onSetBest: (modelId: string) => void;
  onNavigateToPredict: (modelId: string) => void;
}

export const ModelComparison: React.FC<ModelComparisonProps> = ({
  models,
  onSelectModel,
  onSetBest,
  onNavigateToPredict,
}) => {
  const [filterTask, setFilterTask] = useState<string>('all');
  const [sortMetric, setSortMetric] = useState<string>('default');

  const filtered = models.filter((m) => {
    if (filterTask === 'all') return true;
    return m.task_type === filterTask;
  });

  const sorted = [...filtered].sort((a, b) => {
    if (sortMetric === 'accuracy') {
      return (Number(b.metrics['ACCURACY']) || 0) - (Number(a.metrics['ACCURACY']) || 0);
    }
    if (sortMetric === 'auc') {
      return (Number(b.metrics['AUC']) || 0) - (Number(a.metrics['AUC']) || 0);
    }
    if (sortMetric === 'r2') {
      return (Number(b.metrics['R2']) || 0) - (Number(a.metrics['R2']) || 0);
    }
    if (sortMetric === 'rmse') {
      return (Number(a.metrics['RMSE']) || 9999) - (Number(b.metrics['RMSE']) || 9999);
    }
    // Default: best first, then newest
    if (b.is_best !== a.is_best) return (b.is_best ? 1 : 0) - (a.is_best ? 1 : 0);
    return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
  });

  return (
    <div className="flex-1 bg-[#0b0f17] p-6 overflow-y-auto space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800/80 pb-4">
        <div>
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <LineChart className="w-5 h-5 text-cyan-400" />
            Model Comparison Leaderboard & Benchmarking
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Empirical benchmark rankings across all trained candidate pipelines. No synthetic scores.
          </p>
        </div>

        {/* Filters */}
        <div className="flex items-center gap-3 text-xs">
          <div className="flex items-center gap-1.5">
            <span className="text-slate-500">Filter:</span>
            <select
              value={filterTask}
              onChange={(e) => setFilterTask(e.target.value)}
              className="bg-slate-900 border border-slate-700 text-slate-200 text-xs rounded px-2.5 py-1 font-mono"
            >
              <option value="all">All Tasks</option>
              <option value="classification">Classification</option>
              <option value="regression">Regression</option>
            </select>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-slate-500">Sort by:</span>
            <select
              value={sortMetric}
              onChange={(e) => setSortMetric(e.target.value)}
              className="bg-slate-900 border border-slate-700 text-slate-200 text-xs rounded px-2.5 py-1 font-mono"
            >
              <option value="default">Default (Best / Date)</option>
              <option value="accuracy">Accuracy (Desc)</option>
              <option value="auc">ROC-AUC (Desc)</option>
              <option value="r2">R² Score (Desc)</option>
              <option value="rmse">RMSE (Asc)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Visual Metric Bar Comparison */}
      {sorted.length > 0 && (
        <div className="bg-[#111827]/70 border border-slate-800 rounded-lg p-5">
          <h3 className="text-xs font-semibold text-slate-200 uppercase tracking-wider mb-4">
            Comparative Performance Overview
          </h3>
          <div className="space-y-3">
            {sorted.map((m) => {
              const primaryMetric = m.task_type === 'classification'
                ? { label: 'ROC-AUC', val: m.metrics['AUC'] ?? m.metrics['ACCURACY'] ?? 0 }
                : { label: 'R²', val: m.metrics['R2'] ?? 0 };

              const ratio = Math.min(100, Math.max(5, (Number(primaryMetric.val) || 0) * 100));

              return (
                <div key={m.id} className="text-xs font-mono">
                  <div className="flex justify-between items-center mb-1 text-slate-300">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-white">{m.model_name}</span>
                      <span className="text-[10px] text-slate-500">({m.algorithm})</span>
                      {Boolean(m.is_best) && (
                        <span className="text-[10px] text-amber-400 font-bold flex items-center gap-0.5">
                          <Crown className="w-3 h-3 inline" /> BEST
                        </span>
                      )}
                    </div>
                    <span className="text-cyan-400 font-bold">
                      {primaryMetric.label}: {typeof primaryMetric.val === 'number' ? primaryMetric.val.toFixed(4) : primaryMetric.val}
                    </span>
                  </div>
                  <div className="h-3 w-full bg-slate-900 rounded-full overflow-hidden border border-slate-800">
                    <div
                      className={`h-full rounded-full transition-all duration-700 ${
                        m.is_best ? 'bg-gradient-to-r from-amber-500 to-cyan-400' : 'bg-gradient-to-r from-blue-600 to-cyan-500'
                      }`}
                      style={{ width: `${ratio}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Leaderboard Table */}
      <div className="bg-[#111827]/70 border border-slate-800 rounded-lg p-5">
        <h3 className="text-xs font-semibold text-slate-200 uppercase tracking-wider mb-3">
          Experiment Run History ({sorted.length} Models)
        </h3>

        {sorted.length === 0 ? (
          <div className="py-8 text-center text-xs text-slate-500">
            No trained models found. Complete Stage 4 (Train) to populate the leaderboard.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono border-collapse">
              <thead>
                <tr className="bg-slate-900 border-b border-slate-800 text-slate-400 text-[11px]">
                  <th className="p-2.5">Status</th>
                  <th className="p-2.5">Model Name</th>
                  <th className="p-2.5">Algorithm</th>
                  <th className="p-2.5">Task</th>
                  <th className="p-2.5">Accuracy / R²</th>
                  <th className="p-2.5">ROC-AUC / RMSE</th>
                  <th className="p-2.5">F1 / MAE</th>
                  <th className="p-2.5">Training Time</th>
                  <th className="p-2.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-[11px]">
                {sorted.map((m) => {
                  const isClassification = m.task_type === 'classification';
                  return (
                    <tr key={m.id} className="hover:bg-slate-800/40 transition-colors">
                      <td className="p-2.5">
                        {Boolean(m.is_best) ? (
                          <span className="p-1 rounded bg-amber-500/20 text-amber-300 font-bold flex items-center gap-1 w-fit">
                            <Crown className="w-3.5 h-3.5 text-amber-400" /> Best
                          </span>
                        ) : (
                          <button
                            onClick={() => onSetBest(m.id)}
                            className="text-slate-500 hover:text-amber-400 transition-colors cursor-pointer"
                            title="Set as Best"
                          >
                            Set Best
                          </button>
                        )}
                      </td>
                      <td className="p-2.5 font-bold text-white whitespace-nowrap">
                        {m.model_name}
                      </td>
                      <td className="p-2.5 text-cyan-300 font-medium">
                        {m.algorithm}
                      </td>
                      <td className="p-2.5 text-slate-400 capitalize">
                        {m.task_type}
                      </td>
                      <td className="p-2.5 text-slate-200 font-bold">
                        {isClassification
                          ? (m.metrics['ACCURACY']?.toFixed(4) ?? 'N/A')
                          : (m.metrics['R2']?.toFixed(4) ?? 'N/A')}
                      </td>
                      <td className="p-2.5 text-cyan-400 font-bold">
                        {isClassification
                          ? (m.metrics['AUC']?.toFixed(4) ?? 'N/A')
                          : (m.metrics['RMSE']?.toFixed(4) ?? 'N/A')}
                      </td>
                      <td className="p-2.5 text-slate-300">
                        {isClassification
                          ? (m.metrics['F1']?.toFixed(4) ?? 'N/A')
                          : (m.metrics['MAE']?.toFixed(4) ?? 'N/A')}
                      </td>
                      <td className="p-2.5 text-slate-400">
                        {m.training_time_ms} ms
                      </td>
                      <td className="p-2.5 text-right space-x-2 whitespace-nowrap">
                        <button
                          onClick={() => onSelectModel(m)}
                          className="px-2.5 py-1 rounded bg-blue-600 hover:bg-blue-500 text-white font-medium cursor-pointer"
                          title="Inspect in Studio"
                        >
                          <Eye className="w-3 h-3 inline mr-1" /> View
                        </button>
                        <button
                          onClick={() => onNavigateToPredict(m.id)}
                          className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 cursor-pointer"
                          title="Make Prediction"
                        >
                          <Play className="w-3 h-3 inline mr-1" /> Predict
                        </button>
                        <a
                          href={getDownloadModelUrl(m.id)}
                          download
                          className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white inline-block"
                          title="Download binary"
                        >
                          <Download className="w-3 h-3 inline" />
                        </a>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
