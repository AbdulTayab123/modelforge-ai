import React from 'react';
import {
  Home,
  GitBranch,
  Database,
  Box,
  Binary,
  LineChart,
  Scale,
  Sliders,
  Layers,
  Code,
  FileText
} from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  onSelectTab: (tab: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeTab, onSelectTab }) => {
  const navItems = [
    { id: 'dataset', icon: Database, label: 'Datasets' },
    { id: 'explore', icon: GitBranch, label: 'Explore & Profile' },
    { id: 'prepare', icon: Box, label: 'Prepare Pipeline' },
    { id: 'train', icon: Binary, label: 'Train Models' },
    { id: 'models', icon: Layers, label: 'Model Inspector' },
    { id: 'compare', icon: LineChart, label: 'Compare & Leaderboard' },
    { id: 'predict', icon: Sliders, label: 'Prediction Sandbox' },
    { id: 'notebook', icon: Code, label: 'Reproducible Script' },
    { id: 'reports', icon: FileText, label: 'Executive Reports' },
  ];

  return (
    <aside className="w-14 bg-[#0a0f18] border-r border-slate-800/80 flex flex-col items-center py-4 justify-between select-none shrink-0 z-20">
      <div className="flex flex-col items-center gap-2 w-full">
        <button
          onClick={() => onSelectTab('models')}
          className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800/50 transition-colors mb-2 cursor-pointer"
          title="Home"
        >
          <Home className="w-5 h-5" />
        </button>

        <div className="w-8 h-[1px] bg-slate-800 my-1" />

        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onSelectTab(item.id)}
              title={item.label}
              className={`relative p-2.5 rounded-lg transition-all cursor-pointer group flex items-center justify-center ${
                isActive
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30 font-medium'
                  : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800/60'
              }`}
            >
              <Icon className="w-5 h-5" />
              {/* Tooltip on hover */}
              <span className="absolute left-16 px-2.5 py-1 bg-slate-900 border border-slate-700 text-slate-200 text-xs rounded-md shadow-xl whitespace-nowrap opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity z-50">
                {item.label}
              </span>
            </button>
          );
        })}
      </div>

      <div className="text-[10px] text-slate-500 font-mono text-center">
        v1.0
      </div>
    </aside>
  );
};
