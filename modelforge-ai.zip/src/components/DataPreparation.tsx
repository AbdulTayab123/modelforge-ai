import React, { useState, useEffect } from 'react';
import { Box, ShieldCheck, CheckSquare, Square, Settings, ArrowRight, HelpCircle } from 'lucide-react';
import { DatasetItem, TrainConfig } from '../types';

interface DataPreparationProps {
  dataset: DatasetItem | null;
  currentConfig: Partial<TrainConfig>;
  onUpdateConfig: (config: Partial<TrainConfig>) => void;
  onProceedToTrain: () => void;
}

export const DataPreparation: React.FC<DataPreparationProps> = ({
  dataset,
  currentConfig,
  onUpdateConfig,
  onProceedToTrain,
}) => {
  const profile = dataset?.profile;

  const [targetColumn, setTargetColumn] = useState<string>(currentConfig.target_column || '');
  const [taskType, setTaskType] = useState<'classification' | 'regression'>(currentConfig.task_type || 'classification');
  const [featureColumns, setFeatureColumns] = useState<string[]>(currentConfig.feature_columns || []);
  const [numericImputer, setNumericImputer] = useState<string>(currentConfig.numeric_imputer || 'median');
  const [categoricalImputer, setCategoricalImputer] = useState<string>(currentConfig.categorical_imputer || 'most_frequent');
  const [scaler, setScaler] = useState<string>(currentConfig.scaler || 'standard');
  const [testSize, setTestSize] = useState<number>(currentConfig.test_size || 0.2);
  const [randomState, setRandomState] = useState<number>(currentConfig.random_state || 42);

  // Auto-detect target and task type on initial dataset load
  useEffect(() => {
    if (profile && profile.columns.length > 0) {
      // Find candidate target (e.g. Churn, Outcome, MedianHouseValue, Price, or last column)
      let defaultTarget = targetColumn;
      if (!defaultTarget || !profile.columns.find(c => c.name === defaultTarget)) {
        const candidateNames = ['churn', 'outcome', 'target', 'label', 'medianhousevalue', 'price', 'status'];
        const found = profile.columns.find(c => candidateNames.includes(c.name.toLowerCase()));
        defaultTarget = found ? found.name : profile.columns[profile.columns.length - 1].name;
        setTargetColumn(defaultTarget);
      }

      // Detect task type based on target
      const targetColProfile = profile.columns.find(c => c.name === defaultTarget);
      let detectedTaskType: 'classification' | 'regression' = 'classification';
      if (targetColProfile) {
        if (targetColProfile.inferred_type === 'numeric' && targetColProfile.unique_count > 15) {
          detectedTaskType = 'regression';
        } else {
          detectedTaskType = 'classification';
        }
      }
      setTaskType(detectedTaskType);

      // Default features: all columns except target and ID columns
      const defaultFeatures = profile.columns
        .filter(c => c.name !== defaultTarget && !c.name.toLowerCase().includes('id'))
        .map(c => c.name);
      setFeatureColumns(defaultFeatures);
    }
  }, [profile]);

  const handleTargetChange = (newTarget: string) => {
    setTargetColumn(newTarget);
    const targetColProfile = profile?.columns.find(c => c.name === newTarget);
    let detectedTaskType: 'classification' | 'regression' = 'classification';
    if (targetColProfile) {
      if (targetColProfile.inferred_type === 'numeric' && targetColProfile.unique_count > 15) {
        detectedTaskType = 'regression';
      } else {
        detectedTaskType = 'classification';
      }
    }
    setTaskType(detectedTaskType);
    setFeatureColumns(prev => prev.filter(c => c !== newTarget));
  };

  const toggleFeature = (colName: string) => {
    if (featureColumns.includes(colName)) {
      setFeatureColumns(featureColumns.filter(c => c !== colName));
    } else {
      setFeatureColumns([...featureColumns, colName]);
    }
  };

  const selectAllFeatures = () => {
    if (!profile) return;
    const all = profile.columns
      .filter(c => c.name !== targetColumn && !c.name.toLowerCase().includes('id'))
      .map(c => c.name);
    setFeatureColumns(all);
  };

  const deselectAllFeatures = () => {
    setFeatureColumns([]);
  };

  const handleSaveAndProceed = () => {
    if (!dataset) return;
    onUpdateConfig({
      dataset_id: dataset.id,
      target_column: targetColumn,
      task_type: taskType,
      feature_columns: featureColumns,
      numeric_imputer: numericImputer,
      categorical_imputer: categoricalImputer,
      scaler: scaler,
      test_size: testSize,
      random_state: randomState,
    });
    onProceedToTrain();
  };

  if (!dataset || !profile) {
    return (
      <div className="flex-1 bg-[#0b0f17] p-8 flex items-center justify-center text-slate-400 text-sm">
        Please select or upload a dataset first in Stage 1 (Dataset).
      </div>
    );
  }

  const isValid = targetColumn && featureColumns.length > 0;

  return (
    <div className="flex-1 bg-[#0b0f17] p-6 overflow-y-auto space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800/80 pb-4">
        <div>
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <Box className="w-5 h-5 text-indigo-400" />
            Data Preparation & Preprocessing Pipeline
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Configure target objective, select predictive features, set missing-value strategies, and define train/test validation splits.
          </p>
        </div>

        <button
          onClick={handleSaveAndProceed}
          disabled={!isValid}
          className={`px-4 py-2 rounded text-xs font-semibold flex items-center gap-2 shadow-md transition-all cursor-pointer ${
            isValid
              ? 'bg-blue-600 hover:bg-blue-500 text-white'
              : 'bg-slate-800 text-slate-500 cursor-not-allowed'
          }`}
        >
          Proceed to Training <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* Leakage Protection Guarantee Banner */}
      <div className="p-4 rounded-lg bg-blue-950/20 border border-blue-900/40 flex items-start gap-3">
        <ShieldCheck className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
        <div className="text-xs">
          <div className="font-semibold text-cyan-300">Strict Data Leakage Prevention Guarantee</div>
          <div className="text-slate-400 mt-0.5">
            ModelForge AI strictly splits train and test partitions <span className="text-slate-200 font-medium">prior</span> to fitting any scaler or imputer pipeline. Test observations are strictly evaluated on transformers fitted exclusively to training folds.
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Target & Task Setup */}
        <div className="space-y-6 lg:col-span-1">
          {/* Target Column Selection */}
          <div className="bg-[#111827]/70 border border-slate-800 rounded-lg p-5">
            <h3 className="text-xs font-semibold text-slate-200 uppercase tracking-wider mb-3">
              1. Target (Dependent Variable)
            </h3>
            <div className="space-y-2">
              <label className="text-xs text-slate-400">Select Target Column to Predict:</label>
              <select
                value={targetColumn}
                onChange={(e) => handleTargetChange(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 text-cyan-300 text-xs font-mono rounded p-2.5 focus:border-cyan-500 focus:outline-none"
              >
                {profile.columns.map((col) => (
                  <option key={col.name} value={col.name}>
                    {col.name} ({col.inferred_type}, {col.unique_count} unique)
                  </option>
                ))}
              </select>
            </div>

            {/* Task Type Toggle */}
            <div className="mt-4 pt-4 border-t border-slate-800 space-y-2">
              <label className="text-xs text-slate-400">Inferred Task Type:</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setTaskType('classification')}
                  className={`py-2 px-3 rounded text-xs font-medium border text-center transition-colors cursor-pointer ${
                    taskType === 'classification'
                      ? 'bg-blue-600/30 border-blue-500 text-cyan-300 font-semibold'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Classification
                </button>
                <button
                  type="button"
                  onClick={() => setTaskType('regression')}
                  className={`py-2 px-3 rounded text-xs font-medium border text-center transition-colors cursor-pointer ${
                    taskType === 'regression'
                      ? 'bg-blue-600/30 border-blue-500 text-cyan-300 font-semibold'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Regression
                </button>
              </div>
            </div>
          </div>

          {/* Preprocessing Options */}
          <div className="bg-[#111827]/70 border border-slate-800 rounded-lg p-5 space-y-4">
            <h3 className="text-xs font-semibold text-slate-200 uppercase tracking-wider">
              2. Preprocessing Transformers
            </h3>

            <div>
              <label className="text-xs text-slate-400 block mb-1">Numeric Missing Imputation:</label>
              <select
                value={numericImputer}
                onChange={(e) => setNumericImputer(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 text-slate-200 text-xs font-mono rounded p-2 focus:border-cyan-500 focus:outline-none"
              >
                <option value="median">SimpleImputer (Median) [Robust to outliers]</option>
                <option value="mean">SimpleImputer (Mean)</option>
                <option value="most_frequent">SimpleImputer (Most Frequent / Mode)</option>
                <option value="none">None (Drop Missing Rows)</option>
              </select>
            </div>

            <div>
              <label className="text-xs text-slate-400 block mb-1">Numerical Scaling:</label>
              <select
                value={scaler}
                onChange={(e) => setScaler(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 text-slate-200 text-xs font-mono rounded p-2 focus:border-cyan-500 focus:outline-none"
              >
                <option value="standard">StandardScaler (Zero mean, unit variance)</option>
                <option value="minmax">MinMaxScaler (0.0 to 1.0 bounded)</option>
                <option value="robust">RobustScaler (IQR based, outlier proof)</option>
                <option value="none">None (Raw continuous values)</option>
              </select>
            </div>

            <div>
              <label className="text-xs text-slate-400 block mb-1">Categorical Encoding:</label>
              <div className="p-2 bg-slate-900/60 rounded border border-slate-800 text-xs font-mono text-cyan-300">
                OneHotEncoder(handle_unknown='ignore')
              </div>
            </div>
          </div>

          {/* Validation Split */}
          <div className="bg-[#111827]/70 border border-slate-800 rounded-lg p-5 space-y-3">
            <h3 className="text-xs font-semibold text-slate-200 uppercase tracking-wider">
              3. Split Configuration
            </h3>

            <div>
              <div className="flex justify-between text-xs text-slate-400 mb-1">
                <span>Holdout Test Ratio:</span>
                <span className="font-mono text-cyan-400 font-semibold">{Math.round(testSize * 100)}%</span>
              </div>
              <input
                type="range"
                min="0.10"
                max="0.40"
                step="0.05"
                value={testSize}
                onChange={(e) => setTestSize(parseFloat(e.target.value))}
                className="w-full accent-blue-500 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-0.5">
                <span>10% test</span>
                <span>20% (Standard)</span>
                <span>40% test</span>
              </div>
            </div>

            <div className="pt-2">
              <label className="text-xs text-slate-400 block mb-1">Random State Seed:</label>
              <input
                type="number"
                value={randomState}
                onChange={(e) => setRandomState(parseInt(e.target.value) || 42)}
                className="w-full bg-slate-900 border border-slate-700 text-slate-200 text-xs font-mono rounded p-2 focus:border-cyan-500 focus:outline-none"
              />
            </div>
          </div>
        </div>

        {/* Right Column: Feature Columns Selection */}
        <div className="bg-[#111827]/70 border border-slate-800 rounded-lg p-5 lg:col-span-2 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-800">
              <div>
                <h3 className="text-xs font-semibold text-slate-200 uppercase tracking-wider">
                  4. Select Predictive Features ({featureColumns.length} Selected)
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Check all input features to feed into the preprocessor and estimator.
                </p>
              </div>
              <div className="flex items-center gap-2 text-xs">
                <button
                  type="button"
                  onClick={selectAllFeatures}
                  className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-cyan-400 font-mono text-[11px] cursor-pointer"
                >
                  Select All
                </button>
                <button
                  type="button"
                  onClick={deselectAllFeatures}
                  className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-400 font-mono text-[11px] cursor-pointer"
                >
                  Clear
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 max-h-[460px] overflow-y-auto pr-1">
              {profile.columns
                .filter(col => col.name !== targetColumn)
                .map((col) => {
                  const isChecked = featureColumns.includes(col.name);
                  return (
                    <div
                      key={col.name}
                      onClick={() => toggleFeature(col.name)}
                      className={`p-3 rounded-lg border transition-all cursor-pointer flex items-center justify-between select-none ${
                        isChecked
                          ? 'bg-blue-950/30 border-blue-600/60 shadow-sm'
                          : 'bg-slate-900/40 border-slate-800/80 hover:bg-slate-800/50'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 truncate">
                        {isChecked ? (
                          <CheckSquare className="w-4 h-4 text-cyan-400 shrink-0" />
                        ) : (
                          <Square className="w-4 h-4 text-slate-500 shrink-0" />
                        )}
                        <div className="truncate">
                          <div className={`text-xs font-mono font-medium truncate ${isChecked ? 'text-slate-100' : 'text-slate-400'}`}>
                            {col.name}
                          </div>
                          <div className="text-[10px] text-slate-500 font-mono">
                            {col.inferred_type} · {col.unique_count} distinct
                          </div>
                        </div>
                      </div>

                      {col.missing_count > 0 && (
                        <span className="text-[10px] text-amber-400 font-mono px-1.5 py-0.5 rounded bg-amber-950/30">
                          {col.missing_percentage}% null
                        </span>
                      )}
                    </div>
                  );
                })}
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-800 flex items-center justify-between">
            <span className="text-xs text-slate-400 font-mono">
              Target: <span className="text-cyan-400 font-bold">{targetColumn}</span> ({taskType})
            </span>
            <button
              onClick={handleSaveAndProceed}
              disabled={!isValid}
              className={`px-5 py-2.5 rounded text-xs font-semibold flex items-center gap-2 shadow-md transition-all cursor-pointer ${
                isValid
                  ? 'bg-blue-600 hover:bg-blue-500 text-white'
                  : 'bg-slate-800 text-slate-500 cursor-not-allowed'
              }`}
            >
              Confirm Pipeline & Go to Train <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
