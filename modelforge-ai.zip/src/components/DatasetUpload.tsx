import React, { useState } from 'react';
import { Upload, FileSpreadsheet, CheckCircle2, AlertTriangle, Database, ArrowRight, RefreshCw, Eye } from 'lucide-react';
import { DatasetItem } from '../types';
import { uploadDatasetFile } from '../api';

interface DatasetUploadProps {
  datasets: DatasetItem[];
  selectedDataset: DatasetItem | null;
  onSelectDataset: (dataset: DatasetItem) => void;
  onDatasetUploaded: (dataset: DatasetItem) => void;
  onProceedToExplore: () => void;
}

export const DatasetUpload: React.FC<DatasetUploadProps> = ({
  datasets,
  selectedDataset,
  onSelectDataset,
  onDatasetUploaded,
  onProceedToExplore,
}) => {
  const [isUploading, setIsUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [dragActive, setDragActive] = useState(false);

  const handleFileUpload = async (file: File) => {
    if (!file.name.endsWith('.csv')) {
      setUploadError('Please select a valid CSV file.');
      return;
    }
    setUploadError(null);
    setIsUploading(true);
    try {
      const newDataset = await uploadDatasetFile(file);
      onDatasetUploaded(newDataset);
    } catch (err: any) {
      setUploadError(err.message || 'Upload failed');
    } finally {
      setIsUploading(false);
    }
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileUpload(e.dataTransfer.files[0]);
    }
  };

  const currentProfile = selectedDataset?.profile;

  return (
    <div className="flex-1 bg-[#0b0f17] p-6 overflow-y-auto space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800/80 pb-4">
        <div>
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <Database className="w-5 h-5 text-blue-500" />
            Dataset Import & Schema Validation
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Upload custom CSV files or select a production-grade pre-configured sample dataset to start the ML workflow.
          </p>
        </div>

        {selectedDataset && (
          <button
            onClick={onProceedToExplore}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded text-xs font-semibold flex items-center gap-2 shadow-md cursor-pointer"
          >
            Explore Dataset <ArrowRight className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Dataset Selection & Upload Area */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Upload Dropzone */}
        <div className="lg:col-span-1 bg-[#111827]/70 border border-slate-800 rounded-lg p-5 flex flex-col justify-between">
          <div>
            <h3 className="text-xs font-semibold text-slate-200 uppercase tracking-wider mb-2">
              Upload New CSV
            </h3>
            <div
              onDragOver={(e) => { e.preventDefault(); setDragActive(true); }}
              onDragLeave={() => setDragActive(false)}
              onDrop={onDrop}
              className={`border-2 border-dashed rounded-lg p-6 text-center transition-all ${
                dragActive
                  ? 'border-cyan-400 bg-cyan-950/20'
                  : 'border-slate-700 hover:border-slate-600 bg-slate-900/50'
              }`}
            >
              <FileSpreadsheet className="w-10 h-10 text-cyan-400 mx-auto mb-2 opacity-80" />
              <div className="text-xs font-medium text-slate-200 mb-1">
                Drag and drop your CSV here
              </div>
              <div className="text-[11px] text-slate-500 mb-4">
                Strict client validation & data sanitization
              </div>

              <label className="inline-block px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-xs font-medium border border-slate-700 cursor-pointer transition-colors">
                {isUploading ? (
                  <span className="flex items-center gap-2">
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" /> Uploading...
                  </span>
                ) : (
                  'Browse CSV File'
                )}
                <input
                  type="file"
                  accept=".csv"
                  className="hidden"
                  onChange={(e) => {
                    if (e.target.files?.[0]) handleFileUpload(e.target.files[0]);
                  }}
                  disabled={isUploading}
                />
              </label>
            </div>

            {uploadError && (
              <div className="mt-3 p-2.5 rounded bg-red-950/40 border border-red-800/60 text-red-300 text-xs flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0 text-red-400" />
                <span>{uploadError}</span>
              </div>
            )}
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800/80 text-[11px] text-slate-500 font-mono">
            Max size: 50MB · Encrypted in memory · No external leak
          </div>
        </div>

        {/* Available Datasets List */}
        <div className="lg:col-span-2 bg-[#111827]/70 border border-slate-800 rounded-lg p-5">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-xs font-semibold text-slate-200 uppercase tracking-wider">
              Available Datasets ({datasets.length})
            </h3>
            <span className="text-[11px] text-slate-400">Select one to inspect preview</span>
          </div>

          <div className="space-y-2.5 max-h-[300px] overflow-y-auto pr-1">
            {datasets.map((ds) => {
              const isSelected = selectedDataset?.id === ds.id;
              return (
                <div
                  key={ds.id}
                  onClick={() => onSelectDataset(ds)}
                  className={`p-3.5 rounded-lg border transition-all cursor-pointer flex items-center justify-between ${
                    isSelected
                      ? 'bg-blue-950/40 border-blue-500/80 shadow-md shadow-blue-950/50'
                      : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 hover:bg-slate-900'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded ${isSelected ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-400'}`}>
                      <FileSpreadsheet className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-semibold text-slate-200 flex items-center gap-2">
                        {ds.name}
                        {Boolean(ds.is_sample) && (
                          <span className="px-1.5 py-0.2 rounded bg-cyan-950/60 border border-cyan-800/60 text-cyan-400 text-[10px] font-mono">
                            Sample
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-slate-400 font-mono mt-0.5">
                        {ds.filename} · {ds.row_count.toLocaleString()} rows · {ds.col_count} columns · {(ds.file_size_bytes / 1024).toFixed(1)} KB
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {isSelected ? (
                      <span className="text-xs text-cyan-400 font-medium flex items-center gap-1 font-mono">
                        <CheckCircle2 className="w-4 h-4" /> Selected
                      </span>
                    ) : (
                      <span className="text-xs text-slate-500 hover:text-slate-300">Select</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Dataset Health & Summary Cards */}
      {selectedDataset && currentProfile && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="p-3.5 bg-slate-900/60 border border-slate-800 rounded-lg">
              <div className="text-[10px] text-slate-500 font-mono uppercase">Total Rows</div>
              <div className="text-lg font-bold text-slate-100 font-mono mt-1">
                {currentProfile.total_rows.toLocaleString()}
              </div>
            </div>
            <div className="p-3.5 bg-slate-900/60 border border-slate-800 rounded-lg">
              <div className="text-[10px] text-slate-500 font-mono uppercase">Total Features</div>
              <div className="text-lg font-bold text-cyan-400 font-mono mt-1">
                {currentProfile.total_columns}
              </div>
            </div>
            <div className="p-3.5 bg-slate-900/60 border border-slate-800 rounded-lg">
              <div className="text-[10px] text-slate-500 font-mono uppercase">Duplicate Rows</div>
              <div className={`text-lg font-bold font-mono mt-1 ${currentProfile.duplicate_rows > 0 ? 'text-amber-400' : 'text-emerald-400'}`}>
                {currentProfile.duplicate_rows}
              </div>
            </div>
            <div className="p-3.5 bg-slate-900/60 border border-slate-800 rounded-lg">
              <div className="text-[10px] text-slate-500 font-mono uppercase">Health Status</div>
              <div className="text-sm font-semibold text-emerald-400 mt-1.5 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4" /> Ready for Training
              </div>
            </div>
          </div>

          {/* Validation Warnings */}
          {currentProfile.warnings && currentProfile.warnings.length > 0 && (
            <div className="p-3.5 bg-amber-950/20 border border-amber-800/40 rounded-lg text-xs text-amber-300 space-y-1">
              <div className="font-semibold flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4 text-amber-400" /> Validation Notes:
              </div>
              <ul className="list-disc pl-5 space-y-0.5 text-amber-200/90 text-[11px]">
                {currentProfile.warnings.map((w, idx) => (
                  <li key={idx}>{w}</li>
                ))}
              </ul>
            </div>
          )}

          {/* Table Rows Preview */}
          <div className="bg-[#111827]/70 border border-slate-800 rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-xs font-semibold text-slate-200 uppercase tracking-wider flex items-center gap-2">
                <Eye className="w-4 h-4 text-slate-400" />
                Raw Data Preview (First 20 Rows)
              </h3>
              <span className="text-[11px] text-slate-500 font-mono">
                Showing {Math.min(20, currentProfile.preview?.length || 0)} of {currentProfile.total_rows} rows
              </span>
            </div>

            <div className="overflow-x-auto border border-slate-800 rounded">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-900/80 border-b border-slate-800">
                    <th className="p-2.5 font-mono text-[11px] text-slate-500 uppercase">#</th>
                    {currentProfile.columns.map((col) => (
                      <th key={col.name} className="p-2.5 font-mono text-[11px] text-slate-300 whitespace-nowrap">
                        <div className="font-semibold">{col.name}</div>
                        <div className="text-[10px] text-slate-500 font-normal">
                          {col.inferred_type} ({col.dtype})
                        </div>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono text-[11px]">
                  {currentProfile.preview?.map((row, rowIdx) => (
                    <tr key={rowIdx} className="hover:bg-slate-800/30 transition-colors">
                      <td className="p-2 text-slate-500">{rowIdx + 1}</td>
                      {currentProfile.columns.map((col) => (
                        <td key={col.name} className="p-2 text-slate-300 whitespace-nowrap">
                          {row[col.name] !== undefined && row[col.name] !== null ? String(row[col.name]) : (
                            <span className="text-amber-500/70 italic">null</span>
                          )}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
