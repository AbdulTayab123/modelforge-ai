import React, { useState } from 'react';
import { BarChart3, TrendingUp, Grid, AlertCircle, ArrowRight, Table2 } from 'lucide-react';
import { DatasetItem, ColumnProfile } from '../types';

interface ExploratoryAnalysisProps {
  dataset: DatasetItem | null;
  onProceedToPrepare: () => void;
}

export const ExploratoryAnalysis: React.FC<ExploratoryAnalysisProps> = ({
  dataset,
  onProceedToPrepare,
}) => {
  const [selectedColumnName, setSelectedColumnName] = useState<string | null>(null);
  const profile = dataset?.profile;

  if (!dataset || !profile) {
    return (
      <div className="flex-1 bg-[#0b0f17] p-8 flex items-center justify-center text-slate-400 text-sm">
        Please select or upload a dataset first in Stage 1 (Dataset).
      </div>
    );
  }

  const selectedCol: ColumnProfile | undefined = profile.columns.find(
    c => c.name === (selectedColumnName || profile.columns[0]?.name)
  ) || profile.columns[0];

  const numericCols = profile.columns.filter(c => c.inferred_type === 'numeric');
  const correlationKeys = Object.keys(profile.correlations || {});

  return (
    <div className="flex-1 bg-[#0b0f17] p-6 overflow-y-auto space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800/80 pb-4">
        <div>
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-cyan-400" />
            Exploratory Data Analysis & Feature Distributions
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Real descriptive statistics, empirical distributions, null frequency, and correlation heatmap calculated from <span className="text-cyan-300 font-mono">{dataset.name}</span>.
          </p>
        </div>

        <button
          onClick={onProceedToPrepare}
          className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded text-xs font-semibold flex items-center gap-2 shadow-md cursor-pointer"
        >
          Prepare Pipeline <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* Feature Selector & Distribution Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Columns List */}
        <div className="bg-[#111827]/70 border border-slate-800 rounded-lg p-4 lg:col-span-1">
          <h3 className="text-xs font-semibold text-slate-200 uppercase tracking-wider mb-3">
            Select Feature ({profile.columns.length})
          </h3>
          <div className="space-y-1.5 max-h-[360px] overflow-y-auto pr-1">
            {profile.columns.map((col) => {
              const isSelected = selectedCol?.name === col.name;
              return (
                <button
                  key={col.name}
                  onClick={() => setSelectedColumnName(col.name)}
                  className={`w-full text-left p-2.5 rounded text-xs transition-colors cursor-pointer flex items-center justify-between ${
                    isSelected
                      ? 'bg-blue-600 text-white font-medium'
                      : 'bg-slate-900/50 hover:bg-slate-800 text-slate-300'
                  }`}
                >
                  <div className="truncate font-mono">
                    <span className="font-semibold">{col.name}</span>
                    <span className={`ml-2 text-[10px] ${isSelected ? 'text-blue-100' : 'text-slate-500'}`}>
                      {col.inferred_type}
                    </span>
                  </div>
                  <span className={`text-[10px] font-mono ${col.missing_count > 0 ? (isSelected ? 'text-amber-200' : 'text-amber-400') : (isSelected ? 'text-blue-200' : 'text-slate-500')}`}>
                    {col.missing_count > 0 ? `${col.missing_percentage}% null` : '0 null'}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right: Selected Feature Deep Dive & Distribution Chart */}
        <div className="bg-[#111827]/70 border border-slate-800 rounded-lg p-5 lg:col-span-2 flex flex-col justify-between">
          {selectedCol && (
            <div>
              <div className="flex items-center justify-between mb-4 border-b border-slate-800 pb-3">
                <div>
                  <h3 className="text-sm font-bold text-white font-mono flex items-center gap-2">
                    {selectedCol.name}
                    <span className="text-xs px-2 py-0.5 rounded bg-slate-800 text-cyan-300 font-mono font-normal">
                      {selectedCol.inferred_type} · {selectedCol.dtype}
                    </span>
                  </h3>
                  <div className="text-xs text-slate-400 mt-1 font-mono">
                    Unique values: {selectedCol.unique_count} · Missing: {selectedCol.missing_count} ({selectedCol.missing_percentage}%)
                  </div>
                </div>
              </div>

              {/* Distribution rendering */}
              {selectedCol.inferred_type === 'numeric' && selectedCol.stats ? (
                <div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono mb-5">
                    <div className="p-2.5 bg-slate-900 rounded border border-slate-800">
                      <span className="text-[10px] text-slate-500 uppercase">Mean</span>
                      <div className="text-slate-200 font-semibold mt-0.5">{selectedCol.stats.mean}</div>
                    </div>
                    <div className="p-2.5 bg-slate-900 rounded border border-slate-800">
                      <span className="text-[10px] text-slate-500 uppercase">Median (P50)</span>
                      <div className="text-cyan-400 font-semibold mt-0.5">{selectedCol.stats.median}</div>
                    </div>
                    <div className="p-2.5 bg-slate-900 rounded border border-slate-800">
                      <span className="text-[10px] text-slate-500 uppercase">Std Deviation</span>
                      <div className="text-slate-200 font-semibold mt-0.5">{selectedCol.stats.std}</div>
                    </div>
                    <div className="p-2.5 bg-slate-900 rounded border border-slate-800">
                      <span className="text-[10px] text-slate-500 uppercase">Skewness</span>
                      <div className="text-slate-200 font-semibold mt-0.5">{selectedCol.stats.skewness}</div>
                    </div>
                  </div>

                  {/* Histogram bins chart */}
                  <div className="space-y-2">
                    <div className="text-xs text-slate-400 font-medium">Binned Frequency Histogram:</div>
                    <div className="h-44 flex items-end gap-2 pt-6 px-2 bg-slate-900/60 rounded border border-slate-800">
                      {selectedCol.stats.histogram?.map((bin, i) => {
                        const maxCount = Math.max(...(selectedCol.stats?.histogram.map(h => h.count) || [1]), 1);
                        const heightPct = (bin.count / maxCount) * 100;
                        return (
                          <div key={i} className="flex-1 flex flex-col items-center h-full justify-end group relative">
                            <div className="text-[9px] text-slate-400 mb-1 opacity-0 group-hover:opacity-100 transition-opacity font-mono">
                              {bin.count}
                            </div>
                            <div
                              className="w-full bg-gradient-to-t from-blue-600 to-cyan-400 rounded-t transition-all group-hover:brightness-125"
                              style={{ height: `${Math.max(4, heightPct)}%` }}
                            />
                            <div className="text-[8px] text-slate-500 font-mono mt-1 truncate w-full text-center">
                              {bin.bin_start}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              ) : (
                /* Categorical breakdown */
                <div className="space-y-3">
                  <div className="text-xs text-slate-400 font-medium">Top Category Frequencies:</div>
                  <div className="space-y-2 max-h-56 overflow-y-auto">
                    {selectedCol.top_categories?.map((cat, i) => (
                      <div key={i} className="text-xs font-mono">
                        <div className="flex justify-between mb-1 text-slate-300">
                          <span>{cat.category}</span>
                          <span className="text-slate-400">{cat.count.toLocaleString()} ({cat.percentage}%)</span>
                        </div>
                        <div className="h-2 w-full bg-slate-900 rounded-full overflow-hidden border border-slate-800">
                          <div
                            className="h-full bg-cyan-500 rounded-full"
                            style={{ width: `${cat.percentage}%` }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Correlation Matrix Heatmap for Numeric Features */}
      {correlationKeys.length > 1 && (
        <div className="bg-[#111827]/70 border border-slate-800 rounded-lg p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-xs font-semibold text-slate-200 uppercase tracking-wider flex items-center gap-2">
                <Grid className="w-4 h-4 text-cyan-400" />
                Correlation Matrix Heatmap (Pearson)
              </h3>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Calculated across {correlationKeys.length} numeric variables. Darker blue indicates strong positive correlation; reddish indicates negative.
              </p>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="text-xs font-mono border-collapse">
              <thead>
                <tr>
                  <th className="p-2 border border-slate-800 bg-slate-900 text-slate-500"></th>
                  {correlationKeys.map(k => (
                    <th key={k} className="p-2 border border-slate-800 bg-slate-900 text-slate-300 whitespace-nowrap text-center">
                      {k}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {correlationKeys.map(rowKey => (
                  <tr key={rowKey}>
                    <td className="p-2 border border-slate-800 bg-slate-900 text-slate-300 font-semibold whitespace-nowrap">
                      {rowKey}
                    </td>
                    {correlationKeys.map(colKey => {
                      const corr = profile.correlations[rowKey]?.[colKey] ?? 0;
                      // Color based on correlation (-1 to +1)
                      let bgStyle = 'bg-slate-900/60 text-slate-400';
                      if (corr > 0.7) bgStyle = 'bg-blue-600/60 text-white font-bold';
                      else if (corr > 0.4) bgStyle = 'bg-blue-700/40 text-cyan-200';
                      else if (corr > 0.1) bgStyle = 'bg-blue-900/30 text-cyan-300';
                      else if (corr < -0.4) bgStyle = 'bg-rose-900/40 text-rose-200';
                      else if (corr < -0.1) bgStyle = 'bg-rose-950/30 text-rose-300';

                      return (
                        <td
                          key={colKey}
                          className={`p-2.5 border border-slate-800 text-center ${bgStyle} transition-all hover:ring-1 hover:ring-cyan-400`}
                          title={`${rowKey} vs ${colKey}: ${corr.toFixed(4)}`}
                        >
                          {corr.toFixed(2)}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Summary Statistics Table for All Columns */}
      <div className="bg-[#111827]/70 border border-slate-800 rounded-lg p-5">
        <h3 className="text-xs font-semibold text-slate-200 uppercase tracking-wider mb-3 flex items-center gap-2">
          <Table2 className="w-4 h-4 text-slate-400" />
          Full Feature Descriptive Statistics
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono border-collapse">
            <thead>
              <tr className="bg-slate-900 border-b border-slate-800 text-slate-400 text-[11px]">
                <th className="p-2.5">Feature</th>
                <th className="p-2.5">Type</th>
                <th className="p-2.5">Missing</th>
                <th className="p-2.5">Unique</th>
                <th className="p-2.5">Mean</th>
                <th className="p-2.5">Std</th>
                <th className="p-2.5">Min</th>
                <th className="p-2.5">Median</th>
                <th className="p-2.5">Max</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-[11px]">
              {profile.columns.map((col) => (
                <tr key={col.name} className="hover:bg-slate-800/30">
                  <td className="p-2.5 text-slate-200 font-semibold">{col.name}</td>
                  <td className="p-2.5 text-slate-400">{col.inferred_type}</td>
                  <td className={`p-2.5 ${col.missing_count > 0 ? 'text-amber-400 font-medium' : 'text-slate-500'}`}>
                    {col.missing_count} ({col.missing_percentage}%)
                  </td>
                  <td className="p-2.5 text-slate-300">{col.unique_count}</td>
                  <td className="p-2.5 text-slate-300">{col.stats?.mean ?? '—'}</td>
                  <td className="p-2.5 text-slate-300">{col.stats?.std ?? '—'}</td>
                  <td className="p-2.5 text-slate-300">{col.stats?.min ?? '—'}</td>
                  <td className="p-2.5 text-slate-300">{col.stats?.median ?? '—'}</td>
                  <td className="p-2.5 text-slate-300">{col.stats?.max ?? '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
