import React, { useState } from 'react';
import { ActualVsPredictedPoint } from '../../types';

interface ResidualsChartProps {
  data?: ActualVsPredictedPoint[];
}

export const ResidualsChart: React.FC<ResidualsChartProps> = ({ data = [] }) => {
  const [hoveredPoint, setHoveredPoint] = useState<ActualVsPredictedPoint | null>(null);

  if (!data || data.length === 0) {
    return (
      <div className="bg-[#0f172a]/70 border border-slate-800/80 rounded-lg p-4 text-xs text-slate-400">
        No actual vs predicted data available.
      </div>
    );
  }

  const width = 440;
  const height = 240;
  const padding = { top: 25, right: 25, bottom: 40, left: 50 };

  const minVal = Math.min(...data.map(d => Math.min(d.actual, d.predicted)));
  const maxVal = Math.max(...data.map(d => Math.max(d.actual, d.predicted)));
  const span = maxVal - minVal || 1;

  const plotWidth = width - padding.left - padding.right;
  const plotHeight = height - padding.top - padding.bottom;

  const getX = (val: number) => padding.left + ((val - minVal) / span) * plotWidth;
  const getY = (val: number) => padding.top + (1 - (val - minVal) / span) * plotHeight;

  return (
    <div className="bg-[#0f172a]/70 border border-slate-800/80 rounded-lg p-4 relative">
      <div className="flex items-center justify-between mb-2">
        <h4 className="text-sm font-semibold text-slate-200">Actual vs. Predicted</h4>
        <div className="flex items-center gap-3 text-xs">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 inline-block" />
            <span className="text-slate-300">Predictions</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-0.5 border-b border-dashed border-slate-500 inline-block" />
            <span className="text-slate-400">Perfect Fit (y = x)</span>
          </div>
        </div>
      </div>

      <div className="relative">
        <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto select-none">
          {/* Grid lines */}
          {[0, 0.25, 0.5, 0.75, 1.0].map((t) => {
            const v = minVal + t * span;
            const x = getX(v);
            const y = getY(v);
            return (
              <React.Fragment key={t}>
                <line x1={padding.left} y1={y} x2={width - padding.right} y2={y} stroke="#1e293b" strokeDasharray="2 2" />
                <line x1={x} y1={padding.top} x2={x} y2={height - padding.bottom} stroke="#1e293b" strokeDasharray="2 2" />
                <text x={padding.left - 6} y={y + 3} textAnchor="end" className="text-[9px] fill-slate-500 font-mono">
                  {v >= 1000 ? `${(v/1000).toFixed(0)}k` : v.toFixed(0)}
                </text>
                <text x={x} y={height - padding.bottom + 14} textAnchor="middle" className="text-[9px] fill-slate-500 font-mono">
                  {v >= 1000 ? `${(v/1000).toFixed(0)}k` : v.toFixed(0)}
                </text>
              </React.Fragment>
            );
          })}

          {/* Perfect fit diagonal line */}
          <line
            x1={getX(minVal)}
            y1={getY(minVal)}
            x2={getX(maxVal)}
            y2={getY(maxVal)}
            stroke="#64748b"
            strokeWidth="1.5"
            strokeDasharray="4 4"
          />

          {/* Scatter Points */}
          {data.map((d, i) => (
            <circle
              key={i}
              cx={getX(d.actual)}
              cy={getY(d.predicted)}
              r={hoveredPoint === d ? 5 : 2.5}
              fill={hoveredPoint === d ? '#38bdf8' : '#0284c7'}
              fillOpacity="0.8"
              stroke="#0f172a"
              strokeWidth="1"
              className="cursor-pointer transition-all"
              onMouseEnter={() => setHoveredPoint(d)}
              onMouseLeave={() => setHoveredPoint(null)}
            />
          ))}

          <text x={-height / 2} y={14} transform="rotate(-90)" textAnchor="middle" className="text-[10px] fill-slate-400 font-medium uppercase">
            Predicted
          </text>
          <text x={width / 2} y={height - 8} textAnchor="middle" className="text-[10px] fill-slate-400 font-medium uppercase">
            Actual
          </text>
        </svg>

        {hoveredPoint && (
          <div className="absolute top-6 right-6 bg-slate-900/95 border border-slate-700 text-slate-200 text-xs rounded px-2.5 py-1.5 font-mono shadow-xl backdrop-blur pointer-events-none">
            <div>Actual: <span className="text-cyan-400">{hoveredPoint.actual.toLocaleString()}</span></div>
            <div>Predicted: <span className="text-emerald-400">{hoveredPoint.predicted.toLocaleString()}</span></div>
            <div>Residual: <span className="text-amber-400">{hoveredPoint.residual.toLocaleString()}</span></div>
          </div>
        )}
      </div>
    </div>
  );
};
