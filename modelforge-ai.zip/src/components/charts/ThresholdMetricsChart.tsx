import React, { useState } from 'react';
import { ThresholdMetricPoint } from '../../types';

interface ThresholdMetricsChartProps {
  data?: ThresholdMetricPoint[];
}

export const ThresholdMetricsChart: React.FC<ThresholdMetricsChartProps> = ({ data = [] }) => {
  const [selectedMetric, setSelectedMetric] = useState<keyof Omit<ThresholdMetricPoint, 'threshold'>>('F1');
  const [hoveredPoint, setHoveredPoint] = useState<ThresholdMetricPoint | null>(null);

  // Fallback points if none provided
  const points = data && data.length > 0 ? data : [
    { threshold: 0.1, F1: 0.55, ACCURACY: 0.65, PRECISION: 0.45, RECALL: 0.95, SPECIFICITY: 0.50 },
    { threshold: 0.2, F1: 0.68, ACCURACY: 0.74, PRECISION: 0.58, RECALL: 0.90, SPECIFICITY: 0.65 },
    { threshold: 0.3, F1: 0.81, ACCURACY: 0.84, PRECISION: 0.75, RECALL: 0.86, SPECIFICITY: 0.82 },
    { threshold: 0.4, F1: 0.89, ACCURACY: 0.91, PRECISION: 0.88, RECALL: 0.85, SPECIFICITY: 0.92 },
    { threshold: 0.5, F1: 0.91, ACCURACY: 0.94, PRECISION: 0.92, RECALL: 0.84, SPECIFICITY: 0.96 },
    { threshold: 0.6, F1: 0.85, ACCURACY: 0.92, PRECISION: 0.95, RECALL: 0.72, SPECIFICITY: 0.98 },
    { threshold: 0.7, F1: 0.74, ACCURACY: 0.88, PRECISION: 0.97, RECALL: 0.55, SPECIFICITY: 0.99 },
    { threshold: 0.8, F1: 0.52, ACCURACY: 0.82, PRECISION: 0.98, RECALL: 0.35, SPECIFICITY: 1.00 },
    { threshold: 0.9, F1: 0.22, ACCURACY: 0.76, PRECISION: 1.00, RECALL: 0.12, SPECIFICITY: 1.00 },
  ];

  const width = 800;
  const height = 240;
  const padding = { top: 30, right: 30, bottom: 45, left: 45 };

  const plotWidth = width - padding.left - padding.right;
  const plotHeight = height - padding.top - padding.bottom;

  const getX = (th: number) => padding.left + th * plotWidth;
  const getY = (val: number) => padding.top + (1 - Math.max(0, Math.min(1, val))) * plotHeight;

  const pathData = points.reduce((acc, p, idx) => {
    const val = Number(p[selectedMetric]) || 0;
    const x = getX(p.threshold);
    const y = getY(val);
    return `${acc} ${idx === 0 ? 'M' : 'L'} ${x} ${y}`;
  }, '');

  return (
    <div className="bg-[#0f172a]/70 border border-slate-800/80 rounded-lg p-5">
      <div className="flex items-center justify-between mb-2">
        <h4 className="text-sm font-semibold text-slate-200">Threshold Metrics</h4>
        <div className="flex items-center gap-2">
          <label className="text-xs text-slate-400">Metric:</label>
          <select
            value={selectedMetric}
            onChange={(e) => setSelectedMetric(e.target.value as any)}
            className="bg-slate-900 border border-slate-700 text-xs text-cyan-300 font-mono rounded px-2.5 py-1 focus:outline-none focus:border-cyan-500"
          >
            <option value="F1">F1 Score</option>
            <option value="ACCURACY">Accuracy</option>
            <option value="PRECISION">Precision</option>
            <option value="RECALL">Recall</option>
            <option value="SPECIFICITY">Specificity</option>
          </select>
        </div>
      </div>

      <div className="text-center text-xs text-slate-400 mb-3">
        Metrics vs. Classification Threshold
      </div>

      <div className="relative">
        <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto select-none">
          {/* Grid lines */}
          {[0, 0.2, 0.4, 0.6, 0.8, 1.0].map((tick) => {
            const y = getY(tick);
            return (
              <React.Fragment key={tick}>
                <line
                  x1={padding.left}
                  y1={y}
                  x2={width - padding.right}
                  y2={y}
                  stroke="#1e293b"
                  strokeWidth="1"
                  strokeDasharray="2 2"
                />
                <text
                  x={padding.left - 8}
                  y={y + 3}
                  textAnchor="end"
                  className="text-[10px] fill-slate-500 font-mono"
                >
                  {tick.toFixed(1)}
                </text>
              </React.Fragment>
            );
          })}

          {[0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0].map((tick) => {
            const x = getX(tick);
            return (
              <React.Fragment key={tick}>
                <line
                  x1={x}
                  y1={padding.top}
                  x2={x}
                  y2={height - padding.bottom}
                  stroke="#1e293b"
                  strokeWidth="1"
                  strokeDasharray="2 2"
                />
                <text
                  x={x}
                  y={height - padding.bottom + 16}
                  textAnchor="middle"
                  className="text-[10px] fill-slate-500 font-mono"
                >
                  {tick.toFixed(1)}
                </text>
              </React.Fragment>
            );
          })}

          {/* Metric curve */}
          <path
            d={pathData}
            fill="none"
            stroke="#38bdf8"
            strokeWidth="3"
            strokeLinecap="round"
            strokeLinejoin="round"
          />

          {/* Data points */}
          {points.map((p, i) => {
            const val = Number(p[selectedMetric]) || 0;
            const isHovered = hoveredPoint === p;
            return (
              <circle
                key={i}
                cx={getX(p.threshold)}
                cy={getY(val)}
                r={isHovered ? 5.5 : 3}
                fill={isHovered ? '#38bdf8' : '#0284c7'}
                stroke="#0f172a"
                strokeWidth="2"
                className="cursor-pointer transition-all"
                onMouseEnter={() => setHoveredPoint(p)}
                onMouseLeave={() => setHoveredPoint(null)}
              />
            );
          })}

          {/* Y-Axis Label */}
          <text
            x={-height / 2}
            y={14}
            transform="rotate(-90)"
            textAnchor="middle"
            className="text-[10px] fill-slate-400 font-medium tracking-wide uppercase"
          >
            Metric Value
          </text>

          {/* X-Axis Label */}
          <text
            x={width / 2}
            y={height - 10}
            textAnchor="middle"
            className="text-[10px] fill-slate-400 font-medium tracking-wide uppercase"
          >
            Threshold
          </text>
        </svg>

        {hoveredPoint && (
          <div className="absolute top-2 right-12 bg-slate-900/95 border border-slate-700 text-slate-200 text-xs rounded px-3 py-1.5 font-mono shadow-xl backdrop-blur pointer-events-none">
            <div>Threshold: <span className="text-cyan-400">{hoveredPoint.threshold.toFixed(2)}</span></div>
            <div>{selectedMetric}: <span className="text-emerald-400">{Number(hoveredPoint[selectedMetric]).toFixed(4)}</span></div>
          </div>
        )}
      </div>
    </div>
  );
};
