import React, { useState } from 'react';
import { RocPoint } from '../../types';

interface RocCurveChartProps {
  data?: RocPoint[];
  auc?: number | null;
}

export const RocCurveChart: React.FC<RocCurveChartProps> = ({ data = [], auc }) => {
  const [hoveredPoint, setHoveredPoint] = useState<RocPoint | null>(null);

  // Fallback points if none provided
  const points = data && data.length > 0 ? data : [
    { fpr: 0, tpr: 0, threshold: 1 },
    { fpr: 0.05, tpr: 0.75, threshold: 0.8 },
    { fpr: 0.15, tpr: 0.88, threshold: 0.6 },
    { fpr: 0.35, tpr: 0.94, threshold: 0.4 },
    { fpr: 0.7, tpr: 0.98, threshold: 0.2 },
    { fpr: 1, tpr: 1, threshold: 0 },
  ];

  const width = 420;
  const height = 240;
  const padding = { top: 30, right: 25, bottom: 40, left: 45 };

  const plotWidth = width - padding.left - padding.right;
  const plotHeight = height - padding.top - padding.bottom;

  const getX = (fpr: number) => padding.left + fpr * plotWidth;
  const getY = (tpr: number) => padding.top + (1 - tpr) * plotHeight;

  // Generate SVG path for ROC curve
  const pathData = points.reduce((acc, p, idx) => {
    const x = getX(p.fpr);
    const y = getY(p.tpr);
    return `${acc} ${idx === 0 ? 'M' : 'L'} ${x} ${y}`;
  }, '');

  return (
    <div className="bg-[#0f172a]/70 border border-slate-800/80 rounded-lg p-4 relative">
      <div className="flex items-center justify-between mb-2">
        <h4 className="text-sm font-semibold text-slate-200">ROC Curve</h4>
        <div className="flex items-center gap-4 text-xs">
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-0.5 bg-[#38bdf8] inline-block rounded" />
            <span className="text-slate-300 font-mono">ROC Curve (AUC = {auc != null ? auc.toFixed(4) : 'N/A'})</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-0.5 border-b border-dashed border-slate-500 inline-block" />
            <span className="text-slate-400">Random</span>
          </div>
        </div>
      </div>

      <div className="relative flex justify-center">
        <svg
          viewBox={`0 0 ${width} ${height}`}
          className="w-full h-auto max-h-[260px] select-none"
        >
          {/* Grid lines */}
          {[0, 0.2, 0.4, 0.6, 0.8, 1.0].map((tick) => {
            const y = getY(tick);
            const x = getX(tick);
            return (
              <React.Fragment key={tick}>
                <line
                  x1={padding.left}
                  y1={y}
                  x2={width - padding.right}
                  y2={y}
                  stroke="#1e293b"
                  strokeWidth="1"
                  strokeDasharray="2 2"
                />
                <line
                  x1={x}
                  y1={padding.top}
                  x2={x}
                  y2={height - padding.bottom}
                  stroke="#1e293b"
                  strokeWidth="1"
                  strokeDasharray="2 2"
                />
                {/* Y-axis labels */}
                <text
                  x={padding.left - 8}
                  y={y + 3}
                  textAnchor="end"
                  className="text-[10px] fill-slate-500 font-mono"
                >
                  {tick.toFixed(1)}
                </text>
                {/* X-axis labels */}
                <text
                  x={x}
                  y={height - padding.bottom + 16}
                  textAnchor="middle"
                  className="text-[10px] fill-slate-500 font-mono"
                >
                  {tick.toFixed(1)}
                </text>
              </React.Fragment>
            );
          })}

          {/* Random Diagonal reference line */}
          <line
            x1={getX(0)}
            y1={getY(0)}
            x2={getX(1)}
            y2={getY(1)}
            stroke="#64748b"
            strokeWidth="1.2"
            strokeDasharray="4 4"
          />

          {/* Filled area under curve */}
          <path
            d={`${pathData} L ${getX(1)} ${getY(0)} L ${getX(0)} ${getY(0)} Z`}
            fill="url(#rocGlow)"
            opacity="0.18"
          />

          {/* ROC Line */}
          <path
            d={pathData}
            fill="none"
            stroke="#38bdf8"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />

          {/* Hover points */}
          {points.map((p, i) => (
            <circle
              key={i}
              cx={getX(p.fpr)}
              cy={getY(p.tpr)}
              r={hoveredPoint === p ? 5 : 2.5}
              fill={hoveredPoint === p ? '#38bdf8' : '#0284c7'}
              stroke="#0f172a"
              strokeWidth="1.5"
              className="cursor-pointer transition-all"
              onMouseEnter={() => setHoveredPoint(p)}
              onMouseLeave={() => setHoveredPoint(null)}
            />
          ))}

          {/* Y-Axis Title */}
          <text
            x={-height / 2}
            y={14}
            transform="rotate(-90)"
            textAnchor="middle"
            className="text-[10px] fill-slate-400 font-medium tracking-wide uppercase"
          >
            True Positive Rate
          </text>

          {/* X-Axis Title */}
          <text
            x={width / 2}
            y={height - 8}
            textAnchor="middle"
            className="text-[10px] fill-slate-400 font-medium tracking-wide uppercase"
          >
            False Positive Rate
          </text>

          <defs>
            <linearGradient id="rocGlow" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.8" />
              <stop offset="100%" stopColor="#38bdf8" stopOpacity="0.0" />
            </linearGradient>
          </defs>
        </svg>

        {hoveredPoint && (
          <div className="absolute top-8 right-8 bg-slate-900/95 border border-slate-700 text-slate-200 text-xs rounded px-2.5 py-1.5 font-mono shadow-xl backdrop-blur pointer-events-none">
            <div>FPR: <span className="text-cyan-400">{hoveredPoint.fpr.toFixed(3)}</span></div>
            <div>TPR: <span className="text-emerald-400">{hoveredPoint.tpr.toFixed(3)}</span></div>
            <div>Cutoff: <span className="text-amber-400">{hoveredPoint.threshold.toFixed(3)}</span></div>
          </div>
        )}
      </div>
    </div>
  );
};
