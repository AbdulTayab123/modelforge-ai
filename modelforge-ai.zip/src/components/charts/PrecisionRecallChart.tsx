import React, { useState } from 'react';
import { PrecisionRecallPoint } from '../../types';

interface PrecisionRecallChartProps {
  data?: PrecisionRecallPoint[];
  aucPr?: number | null;
}

export const PrecisionRecallChart: React.FC<PrecisionRecallChartProps> = ({ data = [], aucPr }) => {
  const [hoveredPoint, setHoveredPoint] = useState<PrecisionRecallPoint | null>(null);

  const points = data && data.length > 0 ? data : [
    { recall: 0, precision: 1 },
    { recall: 0.2, precision: 0.95 },
    { recall: 0.5, precision: 0.88 },
    { recall: 0.75, precision: 0.76 },
    { recall: 0.9, precision: 0.62 },
    { recall: 1, precision: 0.35 },
  ];

  const width = 360;
  const height = 220;
  const padding = { top: 25, right: 20, bottom: 35, left: 40 };

  const plotWidth = width - padding.left - padding.right;
  const plotHeight = height - padding.top - padding.bottom;

  const getX = (rec: number) => padding.left + rec * plotWidth;
  const getY = (prec: number) => padding.top + (1 - prec) * plotHeight;

  const pathData = points.reduce((acc, p, idx) => {
    const x = getX(p.recall);
    const y = getY(p.precision);
    return `${acc} ${idx === 0 ? 'M' : 'L'} ${x} ${y}`;
  }, '');

  return (
    <div className="bg-[#0f172a]/70 border border-slate-800/80 rounded-lg p-4 relative">
      <div className="flex items-center justify-between mb-2">
        <h4 className="text-sm font-semibold text-slate-200">Precision-Recall</h4>
        <div className="flex items-center gap-1.5 text-xs">
          <span className="w-2.5 h-2.5 bg-[#f43f5e] inline-block rounded-xs" />
          <span className="text-slate-300 font-mono text-[11px]">Precision-Recall Curve</span>
        </div>
      </div>

      <div className="relative flex justify-center">
        <svg
          viewBox={`0 0 ${width} ${height}`}
          className="w-full h-auto max-h-[220px] select-none"
        >
          {/* Grid lines */}
          {[0, 0.2, 0.4, 0.6, 0.8, 1.0].map((tick) => {
            const y = getY(tick);
            const x = getX(tick);
            return (
              <React.Fragment key={tick}>
                <line
                  x1={padding.left}
                  y1={y}
                  x2={width - padding.right}
                  y2={y}
                  stroke="#1e293b"
                  strokeWidth="1"
                  strokeDasharray="2 2"
                />
                <line
                  x1={x}
                  y1={padding.top}
                  x2={x}
                  y2={height - padding.bottom}
                  stroke="#1e293b"
                  strokeWidth="1"
                  strokeDasharray="2 2"
                />
                <text
                  x={padding.left - 6}
                  y={y + 3}
                  textAnchor="end"
                  className="text-[9px] fill-slate-500 font-mono"
                >
                  {tick.toFixed(1)}
                </text>
                <text
                  x={x}
                  y={height - padding.bottom + 14}
                  textAnchor="middle"
                  className="text-[9px] fill-slate-500 font-mono"
                >
                  {tick.toFixed(1)}
                </text>
              </React.Fragment>
            );
          })}

          {/* Area fill */}
          <path
            d={`${pathData} L ${getX(1)} ${getY(0)} L ${getX(0)} ${getY(0)} Z`}
            fill="#f43f5e"
            opacity="0.12"
          />

          {/* PR Line */}
          <path
            d={pathData}
            fill="none"
            stroke="#f43f5e"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />

          {points.map((p, i) => (
            <circle
              key={i}
              cx={getX(p.recall)}
              cy={getY(p.precision)}
              r={hoveredPoint === p ? 4.5 : 2}
              fill={hoveredPoint === p ? '#fda4af' : '#f43f5e'}
              className="cursor-pointer transition-all"
              onMouseEnter={() => setHoveredPoint(p)}
              onMouseLeave={() => setHoveredPoint(null)}
            />
          ))}

          <text
            x={-height / 2}
            y={12}
            transform="rotate(-90)"
            textAnchor="middle"
            className="text-[9px] fill-slate-400 font-medium tracking-wide uppercase"
          >
            Precision
          </text>

          <text
            x={width / 2}
            y={height - 6}
            textAnchor="middle"
            className="text-[9px] fill-slate-400 font-medium tracking-wide uppercase"
          >
            Recall
          </text>
        </svg>

        {hoveredPoint && (
          <div className="absolute top-6 right-6 bg-slate-900/95 border border-slate-700 text-slate-200 text-xs rounded px-2.5 py-1 font-mono shadow-xl backdrop-blur pointer-events-none">
            <div>Recall: <span className="text-cyan-400">{hoveredPoint.recall.toFixed(3)}</span></div>
            <div>Precision: <span className="text-rose-400">{hoveredPoint.precision.toFixed(3)}</span></div>
          </div>
        )}
      </div>
    </div>
  );
};
