import React from 'react';

interface RadarMetricsChartProps {
  metrics: Record<string, number | null>;
  modelName?: string;
}

export const RadarMetricsChart: React.FC<RadarMetricsChartProps> = ({ metrics, modelName = 'Current Model' }) => {
  // Normalize each metric to [0, 1] where 1 is best
  const rawAuc = metrics['AUC'] ?? 0.65;
  const rawAucPr = metrics['AUC-PR'] ?? 0.40;
  const rawAcc = metrics['ACCURACY'] ?? 0.85;

  // For losses (MSE, RMSE, LogLoss), lower is better, so invert normalized score: 1 / (1 + val)
  const rawLogLoss = metrics['LOGLOSS'] ?? 0.65;
  const rawRmse = metrics['RMSE'] ?? 0.47;
  const rawMse = metrics['MSE'] ?? 0.22;

  const normalizedLogLoss = 1 / (1 + rawLogLoss);
  const normalizedRmse = 1 / (1 + rawRmse);
  const normalizedMse = 1 / (1 + rawMse);

  const axes = [
    { label: 'AUC', value: Math.min(1, Math.max(0, rawAuc)) },
    { label: 'AUC-PR', value: Math.min(1, Math.max(0, rawAucPr)) },
    { label: 'Accuracy', value: Math.min(1, Math.max(0, rawAcc)) },
    { label: 'LogLoss', value: Math.min(1, Math.max(0, normalizedLogLoss)) },
    { label: 'RMSE', value: Math.min(1, Math.max(0, normalizedRmse)) },
    { label: 'MSE', value: Math.min(1, Math.max(0, normalizedMse)) },
  ];

  const size = 320;
  const center = size / 2;
  const radius = size * 0.38;
  const angleStep = (Math.PI * 2) / axes.length;

  const getCoordinates = (value: number, index: number) => {
    const angle = index * angleStep - Math.PI / 2;
    const r = value * radius;
    return {
      x: center + r * Math.cos(angle),
      y: center + r * Math.sin(angle),
    };
  };

  const getLabelCoordinates = (index: number) => {
    const angle = index * angleStep - Math.PI / 2;
    const r = radius + 22;
    return {
      x: center + r * Math.cos(angle),
      y: center + r * Math.sin(angle),
    };
  };

  const polygonPoints = axes.map((a, i) => {
    const { x, y } = getCoordinates(a.value, i);
    return `${x},${y}`;
  }).join(' ');

  return (
    <div className="bg-[#0f172a]/70 border border-slate-800/80 rounded-lg p-4">
      <div className="text-center mb-2">
        <h4 className="text-sm font-semibold text-slate-200">Metrics Overview</h4>
        <div className="text-[11px] text-slate-400 mt-0.5">Metrics Overview (normalized 0-1, higher = better)</div>
        <div className="inline-flex items-center gap-2 mt-2 px-2.5 py-0.5 rounded bg-blue-950/40 border border-blue-800/40 text-xs text-cyan-300 font-mono">
          <span className="w-2 h-2 rounded-full bg-cyan-400" />
          {modelName}
        </div>
      </div>

      <div className="flex justify-center">
        <svg viewBox={`0 0 ${size} ${size}`} className="w-full max-w-[300px] h-auto select-none">
          {/* Concentric Web Circles */}
          {[0.25, 0.5, 0.75, 1.0].map((level) => {
            const webPoints = axes.map((_, i) => {
              const { x, y } = getCoordinates(level, i);
              return `${x},${y}`;
            }).join(' ');
            return (
              <polygon
                key={level}
                points={webPoints}
                fill="none"
                stroke="#1e293b"
                strokeWidth="1"
                strokeDasharray="2 2"
              />
            );
          })}

          {/* Radial Spokes */}
          {axes.map((_, i) => {
            const { x, y } = getCoordinates(1, i);
            return (
              <line
                key={i}
                x1={center}
                y1={center}
                x2={x}
                y2={y}
                stroke="#1e293b"
                strokeWidth="1"
              />
            );
          })}

          {/* Radar Polygon */}
          <polygon
            points={polygonPoints}
            fill="#38bdf8"
            fillOpacity="0.15"
            stroke="#38bdf8"
            strokeWidth="2.5"
            strokeLinejoin="round"
          />

          {/* Vertices */}
          {axes.map((a, i) => {
            const { x, y } = getCoordinates(a.value, i);
            return (
              <circle
                key={i}
                cx={x}
                cy={y}
                r="3.5"
                fill="#38bdf8"
                stroke="#0f172a"
                strokeWidth="1.5"
              />
            );
          })}

          {/* Axis Labels */}
          {axes.map((a, i) => {
            const { x, y } = getLabelCoordinates(i);
            return (
              <text
                key={i}
                x={x}
                y={y}
                textAnchor="middle"
                dominantBaseline="central"
                className="text-[10px] fill-slate-400 font-mono font-medium"
              >
                {a.label}
              </text>
            );
          })}
        </svg>
      </div>
    </div>
  );
};
