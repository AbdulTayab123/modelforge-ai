import React from 'react';
import { FeatureImportance } from '../../types';

interface FeatureImportanceChartProps {
  data?: FeatureImportance[];
}

export const FeatureImportanceChart: React.FC<FeatureImportanceChartProps> = ({ data = [] }) => {
  if (!data || data.length === 0) {
    return (
      <div className="bg-[#0f172a]/70 border border-slate-800/80 rounded-lg p-6 text-center text-xs text-slate-400">
        No feature importances or model coefficients available for this algorithm.
      </div>
    );
  }

  const maxVal = Math.max(...data.map(d => d.importance), 0.001);

  return (
    <div className="bg-[#0f172a]/70 border border-slate-800/80 rounded-lg p-5">
      <div className="flex items-center justify-between mb-4">
        <h4 className="text-sm font-semibold text-slate-200">Variable / Feature Importance</h4>
        <span className="text-xs text-slate-400 font-mono">Normalized (Top {data.length} Features)</span>
      </div>

      <div className="space-y-2.5">
        {data.map((item, idx) => {
          const ratio = (item.importance / maxVal) * 100;
          return (
            <div key={idx} className="group">
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="font-mono text-slate-300 font-medium group-hover:text-cyan-300 transition-colors">
                  {item.feature}
                </span>
                <span className="font-mono text-slate-400 text-[11px]">
                  {item.importance.toFixed(4)} ({item.percentage.toFixed(1)}%)
                </span>
              </div>
              <div className="h-2 w-full bg-slate-900 rounded-full overflow-hidden border border-slate-800">
                <div
                  className="h-full bg-gradient-to-r from-blue-500 to-cyan-400 rounded-full transition-all duration-500"
                  style={{ width: `${Math.max(2, ratio)}%` }}
                />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
