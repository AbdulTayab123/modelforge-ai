import React from 'react';
import { ConfusionMatrixData } from '../../types';

interface ConfusionMatrixChartProps {
  data?: ConfusionMatrixData;
}

export const ConfusionMatrixChart: React.FC<ConfusionMatrixChartProps> = ({ data }) => {
  const classes = data?.classes || ['CLASS 0', 'CLASS 1'];
  const matrix = data?.matrix || [
    [3335, 154],
    [118, 1393],
  ];

  const total = matrix.flat().reduce((a, b) => a + b, 0);

  return (
    <div className="bg-[#0f172a]/70 border border-slate-800/80 rounded-lg p-4">
      <div className="flex items-center justify-between mb-3">
        <h4 className="text-sm font-semibold text-slate-200">Confusion Matrix</h4>
        <span className="text-[11px] text-slate-400 font-mono">Total Cases: {total.toLocaleString()}</span>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-xs border-collapse">
          <thead>
            <tr>
              <th className="border border-slate-800/60 bg-slate-900/40 p-2 text-slate-500 font-medium"></th>
              <th colSpan={classes.length} className="border border-slate-800 bg-slate-900/80 p-1.5 text-center text-slate-300 font-mono tracking-wider uppercase text-[11px]">
                PREDICTED
              </th>
            </tr>
            <tr>
              <th className="border border-slate-800 bg-slate-900/80 p-2 text-left text-slate-300 font-mono tracking-wider uppercase text-[11px]">
                ACTUAL
              </th>
              {classes.map((c, i) => (
                <th key={i} className="border border-slate-800 bg-slate-900/50 p-2 text-center font-mono text-slate-300">
                  {c.toUpperCase().startsWith('CLASS') ? c.toUpperCase() : `CLASS ${c}`}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {matrix.map((row, rowIdx) => {
              const rowLabel = classes[rowIdx] || `CLASS ${rowIdx}`;
              return (
                <tr key={rowIdx}>
                  <td className="border border-slate-800 bg-slate-900/50 p-2 text-slate-300 font-mono font-medium">
                    {rowLabel.toUpperCase().startsWith('CLASS') ? rowLabel.toUpperCase() : `CLASS ${rowLabel}`}
                  </td>
                  {row.map((val, colIdx) => {
                    const isDiagonal = rowIdx === colIdx;
                    const pct = total > 0 ? ((val / total) * 100).toFixed(1) : '0';
                    return (
                      <td
                        key={colIdx}
                        className={`border border-slate-800 p-3 text-center font-mono transition-colors ${
                          isDiagonal
                            ? 'bg-blue-950/30 text-cyan-300 hover:bg-blue-900/40 font-semibold'
                            : 'bg-slate-900/20 text-slate-400 hover:bg-slate-900/40'
                        }`}
                      >
                        <div className="text-sm font-semibold">{val.toLocaleString()}</div>
                        <div className="text-[10px] text-slate-500 mt-0.5">{pct}%</div>
                      </td>
                    );
                  })}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
