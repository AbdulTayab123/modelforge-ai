/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  fetchHealth,
  fetchDatasets,
  fetchDatasetDetails,
  fetchExperiments,
  setBestModel,
  toggleModelDeployment
} from './api';
import { DatasetItem, ExperimentModel, TrainConfig } from './types';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { ModelView } from './components/ModelView';
import { DatasetUpload } from './components/DatasetUpload';
import { ExploratoryAnalysis } from './components/ExploratoryAnalysis';
import { DataPreparation } from './components/DataPreparation';
import { ModelTraining } from './components/ModelTraining';
import { ModelComparison } from './components/ModelComparison';
import { PredictionSandbox } from './components/PredictionSandbox';
import { NotebookModal } from './components/NotebookModal';
import { ReportModal } from './components/ReportModal';

export default function App() {
  const [activeStage, setActiveStage] = useState<string>('models');
  const [backendInfo, setBackendInfo] = useState<any>(null);
  const [datasets, setDatasets] = useState<DatasetItem[]>([]);
  const [selectedDataset, setSelectedDataset] = useState<DatasetItem | null>(null);
  const [experiments, setExperiments] = useState<ExperimentModel[]>([]);
  const [selectedModel, setSelectedModel] = useState<ExperimentModel | null>(null);
  const [trainConfig, setTrainConfig] = useState<Partial<TrainConfig>>({});

  // Modals state
  const [notebookModalModel, setNotebookModalModel] = useState<ExperimentModel | null>(null);
  const [reportModalModel, setReportModalModel] = useState<ExperimentModel | null>(null);

  // Initialize and load data on boot
  useEffect(() => {
    async function init() {
      try {
        const health = await fetchHealth();
        setBackendInfo(health);
      } catch (err) {
        console.warn('Backend starting up:', err);
      }

      try {
        const dsList = await fetchDatasets();
        setDatasets(dsList);
        if (dsList.length > 0) {
          const firstDs = await fetchDatasetDetails(dsList[0].id);
          setSelectedDataset(firstDs);
        }
      } catch (err) {
        console.error('Error fetching datasets:', err);
      }

      try {
        const expList = await fetchExperiments();
        setExperiments(expList);
        if (expList.length > 0) {
          const best = expList.find(m => Boolean(m.is_best)) || expList[0];
          setSelectedModel(best);
        }
      } catch (err) {
        console.error('Error fetching experiments:', err);
      }
    }

    init();
  }, []);

  const handleSelectDataset = async (dataset: DatasetItem) => {
    try {
      const fullDetails = await fetchDatasetDetails(dataset.id);
      setSelectedDataset(fullDetails);
    } catch {
      setSelectedDataset(dataset);
    }
  };

  const handleDatasetUploaded = async (newDataset: DatasetItem) => {
    setDatasets(prev => [newDataset, ...prev]);
    setSelectedDataset(newDataset);
    setActiveStage('explore');
  };

  const handleModelTrained = (newModel: ExperimentModel) => {
    setExperiments(prev => [newModel, ...prev]);
    setSelectedModel(newModel);
  };

  const handleSetBestModel = async (modelId: string) => {
    try {
      await setBestModel(modelId);
      setExperiments(prev =>
        prev.map(m => ({
          ...m,
          is_best: m.id === modelId ? 1 : 0,
        }))
      );
      if (selectedModel?.id === modelId) {
        setSelectedModel(prev => prev ? { ...prev, is_best: 1 } : null);
      }
    } catch (err) {
      console.error('Failed to set best model:', err);
    }
  };

  const handleDeployModel = async (modelId: string) => {
    try {
      const { is_deployed } = await toggleModelDeployment(modelId);
      setExperiments(prev =>
        prev.map(m => m.id === modelId ? { ...m, is_deployed: is_deployed ? 1 : 0 } : m)
      );
      if (selectedModel?.id === modelId) {
        setSelectedModel(prev => prev ? { ...prev, is_deployed: is_deployed ? 1 : 0 } : null);
      }
    } catch (err) {
      console.error('Failed to toggle model deployment:', err);
    }
  };

  const handleNavigateToPredict = (modelId: string) => {
    const found = experiments.find(m => m.id === modelId);
    if (found) setSelectedModel(found);
    setActiveStage('predict');
  };

  return (
    <div className="flex flex-col h-screen w-screen bg-[#0b0f17] text-slate-100 antialiased overflow-hidden select-none">
      {/* Top Navbar */}
      <Navbar
        backendInfo={backendInfo}
        activeStage={activeStage}
        onSelectStage={(stage) => setActiveStage(stage)}
      />

      {/* Main Workspace: Left Sidebar + Center View */}
      <div className="flex flex-1 min-h-0 w-full overflow-hidden">
        {/* Left Rail */}
        <Sidebar
          activeTab={activeStage}
          onSelectTab={(tab) => {
            if (tab === 'notebook' && selectedModel) {
              setNotebookModalModel(selectedModel);
            } else if (tab === 'reports' && selectedModel) {
              setReportModalModel(selectedModel);
            } else {
              setActiveStage(tab);
            }
          }}
        />

        {/* Dynamic Center Work Area */}
        <main className="flex-1 flex flex-col min-w-0 min-h-0 overflow-hidden bg-[#0b0f17]">
          {activeStage === 'models' && selectedModel && (
            <ModelView
              model={selectedModel}
              allModels={experiments}
              onSelectModel={(m) => setSelectedModel(m)}
              onSetBest={handleSetBestModel}
              onDeploy={handleDeployModel}
              onNavigateToPredict={handleNavigateToPredict}
              onOpenReportModal={(m) => setReportModalModel(m)}
              onOpenNotebookModal={(m) => setNotebookModalModel(m)}
            />
          )}

          {activeStage === 'models' && !selectedModel && (
            <div className="flex-1 flex flex-col items-center justify-center p-8 text-center text-slate-400">
              <p className="text-sm mb-3">No trained models in registry yet.</p>
              <button
                onClick={() => setActiveStage('dataset')}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded text-xs font-semibold cursor-pointer"
              >
                Start with a Dataset
              </button>
            </div>
          )}

          {activeStage === 'dataset' && (
            <DatasetUpload
              datasets={datasets}
              selectedDataset={selectedDataset}
              onSelectDataset={handleSelectDataset}
              onDatasetUploaded={handleDatasetUploaded}
              onProceedToExplore={() => setActiveStage('explore')}
            />
          )}

          {activeStage === 'explore' && (
            <ExploratoryAnalysis
              dataset={selectedDataset}
              onProceedToPrepare={() => setActiveStage('prepare')}
            />
          )}

          {activeStage === 'prepare' && (
            <DataPreparation
              dataset={selectedDataset}
              currentConfig={trainConfig}
              onUpdateConfig={(cfg) => setTrainConfig(prev => ({ ...prev, ...cfg }))}
              onProceedToTrain={() => setActiveStage('train')}
            />
          )}

          {activeStage === 'train' && (
            <ModelTraining
              config={trainConfig}
              onModelTrained={handleModelTrained}
              onNavigateToModel={(m) => {
                setSelectedModel(m);
                setActiveStage('models');
              }}
            />
          )}

          {activeStage === 'compare' && (
            <ModelComparison
              models={experiments}
              onSelectModel={(m) => {
                setSelectedModel(m);
                setActiveStage('models');
              }}
              onSetBest={handleSetBestModel}
              onNavigateToPredict={handleNavigateToPredict}
            />
          )}

          {activeStage === 'predict' && selectedModel && (
            <PredictionSandbox
              model={selectedModel}
              dataset={selectedDataset}
              onNavigateToModel={(m) => {
                setSelectedModel(m);
                setActiveStage('models');
              }}
            />
          )}

          {activeStage === 'predict' && !selectedModel && (
            <div className="flex-1 flex flex-col items-center justify-center p-8 text-center text-slate-400">
              <p className="text-sm mb-3">Select or train a model before running predictions.</p>
              <button
                onClick={() => setActiveStage('train')}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded text-xs font-semibold cursor-pointer"
              >
                Go to Training
              </button>
            </div>
          )}
        </main>
      </div>

      {/* Notebook Modal */}
      {notebookModalModel && (
        <NotebookModal
          model={notebookModalModel}
          onClose={() => setNotebookModalModel(null)}
        />
      )}

      {/* Executive Report Modal */}
      {reportModalModel && (
        <ReportModal
          model={reportModalModel}
          onClose={() => setReportModalModel(null)}
        />
      )}
    </div>
  );
}
