# ModelForge AI — Machine Learning Experimentation Studio

ModelForge AI is a developer-grade machine learning platform for tabular dataset exploration, reproducible data preparation, real supervised learning (regression and classification), model performance auditing, empirical benchmarking, and live inference.

---

## Architecture Overview

- **Frontend**: React 19 + TypeScript + Vite + Tailwind CSS.
  - Guided workflow: **Dataset → Explore → Prepare → Train → Compare → Predict**.
  - Direct reproduction of the CorePlexML developer-tool UI: interactive ROC curves, Precision-Recall curves, Confusion Matrices, Radar Metrics Overview, and Threshold tuning curves.
- **Backend**: Python 3.10+ FastAPI + Pandas + NumPy + Scikit-learn + SQLite.
  - Real data preprocessing via `ColumnTransformer` and `Pipeline` with strict train/test separation to eliminate data leakage.
  - Real Scikit-learn estimators: Gradient Boosting (`GBM`), Random Forest, Logistic Regression, Linear Regression, Ridge, Lasso, Decision Trees, and Naive Bayes.
  - Model serialization via `joblib`.
  - SQLite database (`experiments.db`) for experiment tracking and prediction history.
  - Reproducible standalone Python training scripts (`modelforge_<model>.py`).
- **Server**: Express Node.js runner (`server.ts`) that spawns the Python backend, proxies `/api/*` to FastAPI on port 5000, and mounts Vite middleware on port 3000.

---

## Quickstart

### Prerequisites
- Node.js 18+ and npm
- Python 3.10+ with `pip`

### 1. Install Dependencies

**Node.js Frontend & Server**:
```bash
npm install
```

**Python Backend Stack**:
```bash
pip install -r backend/requirements.txt
```

### 2. Development Mode
Run the full-stack server (automatically spawns FastAPI backend and Vite frontend):
```bash
npm run dev
```
The studio will be available at `http://localhost:3000`.
FastAPI Swagger documentation is accessible at `http://localhost:3000/api/docs`.

### 3. Production Build & Execution
```bash
npm run build
npm start
```

---

## Docker Deployment (Optional)

ModelForge AI includes a multi-stage `Dockerfile` and `docker-compose.yml`:

```bash
docker-compose up --build
```
Access the application at `http://localhost:3000`.

---

## Sample Datasets Included

1. **Telco Customer Churn (Classification)**:
   - 5,000 observations.
   - Features: `SeniorCitizen`, `Partner`, `Dependents`, `Tenure`, `Contract`, `InternetService`, `OnlineSecurity`, `TechSupport`, `MonthlyCharges`, `TotalCharges`.
   - Target: `Churn` (Yes / No).
2. **California Housing Prices (Regression)**:
   - 3,000 observations.
   - Features: `MedInc`, `HouseAge`, `AveRooms`, `AveBedrms`, `Population`, `OceanProximity`.
   - Target: `MedianHouseValue`.
3. **Diabetes Medical Risk (Classification)**:
   - 1,500 clinical observations.
   - Features: `Pregnancies`, `Glucose`, `BloodPressure`, `Insulin`, `BMI`, `DiabetesPedigreeFunction`, `Age`.
   - Target: `Outcome` (0 or 1).

---

## Quality Assurance & Tests

Run linting:
```bash
npm run lint
```

Test backend health:
```bash
curl http://localhost:3000/api/health
```

Test sample model prediction:
```bash
curl -X POST http://localhost:3000/api/predict/<model_id> \
  -H "Content-Type: application/json" \
  -d '{"features": {"SeniorCitizen": 0, "Tenure": 24, "MonthlyCharges": 85.5, ...}}'
```
