import express from 'express';
import http from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import { spawn, ChildProcess } from 'child_process';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = parseInt(process.env.PORT || '3000', 10);
const PYTHON_PORT = 5000;
const isProd = process.env.NODE_ENV === 'production';

let pythonProcess: ChildProcess | null = null;

function startPythonBackend() {
  console.log(`[ModelForge] Spawning Python FastAPI backend on port ${PYTHON_PORT}...`);
  pythonProcess = spawn('python3', [
    '-m', 'uvicorn',
    'backend.main:app',
    '--host', '127.0.0.1',
    '--port', String(PYTHON_PORT),
    '--log-level', 'info'
  ], {
    cwd: __dirname,
    stdio: 'inherit',
    env: { ...process.env, PYTHONPATH: __dirname }
  });

  pythonProcess.on('error', (err) => {
    console.error('[ModelForge] Failed to start Python backend:', err);
  });

  pythonProcess.on('exit', (code, signal) => {
    console.log(`[ModelForge] Python backend exited with code ${code}, signal ${signal}`);
  });
}

process.on('SIGINT', () => {
  if (pythonProcess) pythonProcess.kill('SIGINT');
  process.exit();
});
process.on('SIGTERM', () => {
  if (pythonProcess) pythonProcess.kill('SIGTERM');
  process.exit();
});

async function createServer() {
  const app = express();

  // Start Python backend
  startPythonBackend();

  // Robust Native Stream Proxy for /api/* to FastAPI
  app.use('/api', (req, res) => {
    const targetUrl = new URL(req.originalUrl, `http://127.0.0.1:${PYTHON_PORT}`);

    const options: http.RequestOptions = {
      hostname: '127.0.0.1',
      port: PYTHON_PORT,
      path: targetUrl.pathname + targetUrl.search,
      method: req.method,
      headers: {
        ...req.headers,
        host: `127.0.0.1:${PYTHON_PORT}`,
      },
    };

    const proxyReq = http.request(options, (proxyRes) => {
      res.writeHead(proxyRes.statusCode || 500, proxyRes.headers);
      proxyRes.pipe(res);
    });

    proxyReq.on('error', (err) => {
      console.warn(`[ModelForge Proxy] Error forwarding ${req.method} ${req.originalUrl}:`, err.message);
      if (!res.headersSent) {
        res.status(503).json({
          error: 'Python ML service is starting up. Please retry in a moment.',
          detail: err.message
        });
      }
    });

    req.pipe(proxyReq);
  });

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[ModelForge AI] Running full-stack server on http://0.0.0.0:${PORT}`);
    console.log(`[ModelForge AI] Python ML Engine at http://127.0.0.1:${PYTHON_PORT}`);
  });
}

createServer().catch((err) => {
  console.error('[ModelForge] Failed to initialize server:', err);
  process.exit(1);
});
