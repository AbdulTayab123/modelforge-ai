import os
import numpy as np
import pandas as pd

DATASETS_DIR = os.path.join(os.path.dirname(__file__), "datasets")
os.makedirs(DATASETS_DIR, exist_ok=True)

def generate_sample_datasets():
    np.random.seed(42)

    # 1. Customer Churn Dataset (5,000 rows matching the screenshot)
    churn_path = os.path.join(DATASETS_DIR, "customer_churn.csv")
    if not os.path.exists(churn_path):
        n = 5000
        tenure = np.random.randint(1, 72, size=n)
        monthly_charges = np.random.uniform(18.0, 118.0, size=n).round(2)
        senior_citizen = np.random.choice([0, 1], size=n, p=[0.84, 0.16])
        partner = np.random.choice(["Yes", "No"], size=n, p=[0.48, 0.52])
        dependents = np.random.choice(["Yes", "No"], size=n, p=[0.30, 0.70])
        contract = np.random.choice(["Month-to-month", "One year", "Two year"], size=n, p=[0.55, 0.24, 0.21])
        internet_service = np.random.choice(["DSL", "Fiber optic", "No"], size=n, p=[0.34, 0.44, 0.22])
        online_security = np.random.choice(["Yes", "No", "No internet service"], size=n, p=[0.29, 0.49, 0.22])
        tech_support = np.random.choice(["Yes", "No", "No internet service"], size=n, p=[0.29, 0.49, 0.22])
        payment_method = np.random.choice(["Electronic check", "Mailed check", "Bank transfer", "Credit card"], size=n)
        total_charges = (tenure * monthly_charges + np.random.normal(0, 15, size=n)).clip(18.0).round(2)

        # Churn probability realistic formula
        churn_logits = (
            -0.8
            + (monthly_charges / 100.0) * 1.5
            - (tenure / 72.0) * 2.2
            + (contract == "Month-to-month") * 1.2
            - (contract == "Two year") * 1.5
            + (internet_service == "Fiber optic") * 0.8
            + (tech_support == "No") * 0.6
            + senior_citizen * 0.4
        )
        churn_prob = 1.0 / (1.0 + np.exp(-churn_logits))
        churn = np.where(np.random.rand(n) < churn_prob, "Yes", "No")

        churn_df = pd.DataFrame({
            "CustomerID": [f"CUST-{10000+i}" for i in range(n)],
            "SeniorCitizen": senior_citizen,
            "Partner": partner,
            "Dependents": dependents,
            "Tenure": tenure,
            "Contract": contract,
            "InternetService": internet_service,
            "OnlineSecurity": online_security,
            "TechSupport": tech_support,
            "PaymentMethod": payment_method,
            "MonthlyCharges": monthly_charges,
            "TotalCharges": total_charges,
            "Churn": churn
        })
        churn_df.to_csv(churn_path, index=False)

    # 2. California Housing Prices (3,000 rows regression)
    housing_path = os.path.join(DATASETS_DIR, "california_housing.csv")
    if not os.path.exists(housing_path):
        n = 3000
        med_inc = np.random.lognormal(mean=1.2, sigma=0.5, size=n).round(4)
        house_age = np.random.uniform(1, 52, size=n).round(1)
        ave_rooms = (np.random.normal(5.4, 1.2, size=n)).clip(1.5, 12.0).round(2)
        ave_bedrms = (ave_rooms * np.random.uniform(0.18, 0.28, size=n)).clip(1.0, 4.0).round(2)
        population = np.random.randint(50, 4500, size=n)
        ocean_proximity = np.random.choice(["NEAR BAY", "<1H OCEAN", "INLAND", "NEAR OCEAN", "ISLAND"], size=n, p=[0.11, 0.44, 0.32, 0.12, 0.01])
        
        # Real pricing formula
        base_price = (
            50000
            + med_inc * 42000
            + (ocean_proximity == "<1H OCEAN") * 65000
            + (ocean_proximity == "NEAR BAY") * 75000
            + (ocean_proximity == "NEAR OCEAN") * 60000
            - (ocean_proximity == "INLAND") * 35000
            + ave_rooms * 8000
            - house_age * 400
            + np.random.normal(0, 25000, size=n)
        ).clip(35000, 500000).round(2)

        housing_df = pd.DataFrame({
            "MedInc": med_inc,
            "HouseAge": house_age,
            "AveRooms": ave_rooms,
            "AveBedrms": ave_bedrms,
            "Population": population,
            "OceanProximity": ocean_proximity,
            "MedianHouseValue": base_price
        })
        housing_df.to_csv(housing_path, index=False)

    # 3. Diabetes Medical Risk (1,500 rows classification)
    diabetes_path = os.path.join(DATASETS_DIR, "diabetes_risk.csv")
    if not os.path.exists(diabetes_path):
        n = 1500
        age = np.random.randint(21, 80, size=n)
        bmi = np.random.normal(28.5, 6.0, size=n).clip(18.0, 50.0).round(1)
        glucose = np.random.normal(120, 30, size=n).clip(60, 220).round(1)
        blood_pressure = np.random.normal(72, 12, size=n).clip(50, 110).round(1)
        insulin = np.random.exponential(scale=65, size=n).clip(15, 400).round(1)
        pedigree = np.random.exponential(scale=0.45, size=n).clip(0.08, 2.2).round(3)
        pregnancies = np.random.poisson(lam=2.5, size=n).clip(0, 14)

        prob = 1.0 / (1.0 + np.exp(-(
            -4.5
            + (glucose - 100) * 0.04
            + (bmi - 25) * 0.12
            + (age - 30) * 0.035
            + pedigree * 1.1
            + pregnancies * 0.1
        )))
        outcome = np.where(np.random.rand(n) < prob, 1, 0)

        diab_df = pd.DataFrame({
            "Pregnancies": pregnancies,
            "Glucose": glucose,
            "BloodPressure": blood_pressure,
            "Insulin": insulin,
            "BMI": bmi,
            "DiabetesPedigreeFunction": pedigree,
            "Age": age,
            "Outcome": outcome
        })
        diab_df.to_csv(diabetes_path, index=False)

    return {
        "customer_churn": churn_path,
        "california_housing": housing_path,
        "diabetes_risk": diabetes_path
    }

if __name__ == "__main__":
    generate_sample_datasets()
    print("Sample datasets generated successfully.")
