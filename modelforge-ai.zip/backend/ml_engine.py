import json
import math
import os
import time
import uuid
import joblib
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler, MinMaxScaler, RobustScaler, OneHotEncoder, OrdinalEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression, LinearRegression, Ridge, Lasso
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor, GradientBoostingClassifier, GradientBoostingRegressor
from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score, roc_auc_score,
    average_precision_score, log_loss, confusion_matrix, roc_curve, precision_recall_curve,
    mean_absolute_error, mean_squared_error, r2_score, explained_variance_score
)

MODELS_DIR = os.path.join(os.path.dirname(__file__), "saved_models")
os.makedirs(MODELS_DIR, exist_ok=True)

def sanitize_float(val):
    if val is None or (isinstance(val, (float, np.floating)) and (np.isnan(val) or np.isinf(val))):
        return None
    return float(val)

def profile_dataset(df: pd.DataFrame):
    total_rows = len(df)
    total_cols = len(df.columns)
    duplicate_rows = int(df.duplicated().sum())

    columns_profile = []
    for col in df.columns:
        series = df[col]
        missing_count = int(series.isnull().sum())
        missing_pct = round((missing_count / total_rows) * 100, 2) if total_rows > 0 else 0
        unique_count = int(series.nunique(dropna=True))

        dtype_str = str(series.dtype)
        is_numeric = pd.api.types.is_numeric_dtype(series)

        col_data = {
            "name": col,
            "dtype": dtype_str,
            "inferred_type": "numeric" if is_numeric else "categorical",
            "missing_count": missing_count,
            "missing_percentage": missing_pct,
            "unique_count": unique_count,
            "sample_values": [None if pd.isna(v) else (v if not isinstance(v, (np.integer, np.floating)) else float(v) if isinstance(v, np.floating) else int(v)) for v in series.dropna().head(5).tolist()]
        }

        if is_numeric and len(series.dropna()) > 0:
            clean_s = series.dropna()
            mean_val = float(clean_s.mean())
            std_val = float(clean_s.std()) if len(clean_s) > 1 else 0.0
            min_val = float(clean_s.min())
            p25 = float(clean_s.quantile(0.25))
            median_val = float(clean_s.median())
            p75 = float(clean_s.quantile(0.75))
            max_val = float(clean_s.max())
            skewness = float(clean_s.skew()) if len(clean_s) > 2 else 0.0

            # Calculate histogram bins (10 bins)
            hist_counts, bin_edges = np.histogram(clean_s, bins=min(10, max(3, unique_count)))
            histogram = [
                {"bin_start": round(float(bin_edges[i]), 3), "bin_end": round(float(bin_edges[i+1]), 3), "count": int(hist_counts[i])}
                for i in range(len(hist_counts))
            ]

            col_data["stats"] = {
                "mean": round(mean_val, 4),
                "std": round(std_val, 4),
                "min": round(min_val, 4),
                "p25": round(p25, 4),
                "median": round(median_val, 4),
                "p75": round(p75, 4),
                "max": round(max_val, 4),
                "skewness": round(skewness, 4),
                "histogram": histogram
            }
        else:
            # Top categories
            val_counts = series.dropna().value_counts().head(8)
            col_data["top_categories"] = [
                {"category": str(k), "count": int(v), "percentage": round((v / total_rows) * 100, 2)}
                for k, v in val_counts.items()
            ]

        columns_profile.append(col_data)

    # Correlation matrix for numeric columns
    numeric_df = df.select_dtypes(include=[np.number])
    correlations = {}
    if len(numeric_df.columns) > 1:
        corr_matrix = numeric_df.corr().fillna(0).round(4)
        for col_a in corr_matrix.columns:
            correlations[col_a] = {}
            for col_b in corr_matrix.columns:
                correlations[col_a][col_b] = float(corr_matrix.loc[col_a, col_b])

    # Data health warnings
    warnings = []
    if duplicate_rows > 0:
        warnings.append(f"Found {duplicate_rows} duplicate rows ({round(duplicate_rows/total_rows*100, 1)}% of dataset).")
    high_missing = [c["name"] for c in columns_profile if c["missing_percentage"] > 20]
    if high_missing:
        warnings.append(f"High missing values (>20%) detected in: {', '.join(high_missing)}.")
    if total_rows < 50:
        warnings.append(f"Small dataset size ({total_rows} rows). Train/test metrics may have high variance.")

    return {
        "total_rows": total_rows,
        "total_columns": total_cols,
        "duplicate_rows": duplicate_rows,
        "columns": columns_profile,
        "correlations": correlations,
        "warnings": warnings,
        "preview": json.loads(df.head(20).to_json(orient="records"))
    }

def train_and_evaluate_model(
    df: pd.DataFrame,
    target_column: str,
    feature_columns: list,
    task_type: str, # "classification" or "regression"
    algorithm: str, # "gbm", "random_forest", "logistic_regression", "linear_regression", "decision_tree"
    hyperparameters: dict = None,
    test_size: float = 0.2,
    random_state: int = 42,
    numeric_imputer_strategy: str = "median",
    categorical_imputer_strategy: str = "most_frequent",
    scaler_type: str = "standard", # "standard", "minmax", "robust", "none"
    model_name: str = None
):
    start_time = time.time()
    hyperparameters = hyperparameters or {}

    if target_column not in df.columns:
        raise ValueError(f"Target column '{target_column}' not found in dataset.")

    # Drop rows where target is missing
    clean_df = df.dropna(subset=[target_column]).copy()
    if len(clean_df) < 10:
        raise ValueError(f"Insufficient non-null rows ({len(clean_df)}) for training.")

    X = clean_df[feature_columns].copy()
    y = clean_df[target_column].copy()

    # Determine numerical vs categorical features
    numeric_cols = [c for c in feature_columns if pd.api.types.is_numeric_dtype(X[c])]
    categorical_cols = [c for c in feature_columns if c not in numeric_cols]

    # Preprocessing pipelines
    numeric_transformers = []
    if numeric_imputer_strategy != "none":
        numeric_transformers.append(('imputer', SimpleImputer(strategy=numeric_imputer_strategy)))
    if scaler_type == "standard":
        numeric_transformers.append(('scaler', StandardScaler()))
    elif scaler_type == "minmax":
        numeric_transformers.append(('scaler', MinMaxScaler()))
    elif scaler_type == "robust":
        numeric_transformers.append(('scaler', RobustScaler()))

    categorical_transformers = []
    if categorical_imputer_strategy != "none":
        categorical_transformers.append(('imputer', SimpleImputer(strategy=categorical_imputer_strategy)))
    categorical_transformers.append(('encoder', OneHotEncoder(handle_unknown='ignore', sparse_output=False)))

    transformers = []
    if numeric_cols:
        transformers.append(('num', Pipeline(numeric_transformers) if numeric_transformers else 'passthrough', numeric_cols))
    if categorical_cols:
        transformers.append(('cat', Pipeline(categorical_transformers), categorical_cols))

    preprocessor = ColumnTransformer(transformers=transformers)

    # Classification vs Regression setup
    is_classification = (task_type == "classification")
    classes_list = None
    y_encoded = y

    if is_classification:
        unique_classes = sorted(y.unique().tolist())
        classes_list = [str(c) for c in unique_classes]
        # Map to integer labels if not already
        if not pd.api.types.is_numeric_dtype(y) or set(unique_classes) != set(range(len(unique_classes))):
            class_mapping = {val: idx for idx, val in enumerate(unique_classes)}
            y_encoded = y.map(class_mapping)

        # Stratified train/test split if possible
        can_stratify = True
        val_counts = y_encoded.value_counts()
        if (val_counts < 2).any():
            can_stratify = False

        stratify_param = y_encoded if can_stratify else None
        X_train, X_test, y_train, y_test = train_test_split(
            X, y_encoded, test_size=test_size, random_state=random_state, stratify=stratify_param
        )
    else:
        # Regression
        y_encoded = pd.to_numeric(y, errors='coerce').fillna(0)
        X_train, X_test, y_train, y_test = train_test_split(
            X, y_encoded, test_size=test_size, random_state=random_state
        )

    # Build ML Estimator
    if is_classification:
        if algorithm == "gbm":
            n_est = int(hyperparameters.get("n_estimators", 100))
            lr = float(hyperparameters.get("learning_rate", 0.1))
            max_depth = int(hyperparameters.get("max_depth", 3))
            clf = GradientBoostingClassifier(n_estimators=n_est, learning_rate=lr, max_depth=max_depth, random_state=random_state)
        elif algorithm == "random_forest":
            n_est = int(hyperparameters.get("n_estimators", 100))
            max_depth = int(hyperparameters.get("max_depth", 10)) if hyperparameters.get("max_depth") else None
            clf = RandomForestClassifier(n_estimators=n_est, max_depth=max_depth, random_state=random_state)
        elif algorithm == "decision_tree":
            max_depth = int(hyperparameters.get("max_depth", 6)) if hyperparameters.get("max_depth") else None
            clf = DecisionTreeClassifier(max_depth=max_depth, random_state=random_state)
        elif algorithm == "naive_bayes":
            clf = GaussianNB()
        elif algorithm == "knn":
            n_neighbors = int(hyperparameters.get("n_neighbors", 5))
            clf = KNeighborsClassifier(n_neighbors=n_neighbors)
        else: # logistic_regression
            c_val = float(hyperparameters.get("C", 1.0))
            max_iter = int(hyperparameters.get("max_iter", 500))
            clf = LogisticRegression(C=c_val, max_iter=max_iter, random_state=random_state)
    else:
        # Regression
        if algorithm == "gbm":
            n_est = int(hyperparameters.get("n_estimators", 100))
            lr = float(hyperparameters.get("learning_rate", 0.1))
            max_depth = int(hyperparameters.get("max_depth", 3))
            clf = GradientBoostingRegressor(n_estimators=n_est, learning_rate=lr, max_depth=max_depth, random_state=random_state)
        elif algorithm == "random_forest":
            n_est = int(hyperparameters.get("n_estimators", 100))
            max_depth = int(hyperparameters.get("max_depth", 10)) if hyperparameters.get("max_depth") else None
            clf = RandomForestRegressor(n_estimators=n_est, max_depth=max_depth, random_state=random_state)
        elif algorithm == "decision_tree":
            max_depth = int(hyperparameters.get("max_depth", 6)) if hyperparameters.get("max_depth") else None
            clf = DecisionTreeRegressor(max_depth=max_depth, random_state=random_state)
        elif algorithm == "ridge":
            alpha = float(hyperparameters.get("alpha", 1.0))
            clf = Ridge(alpha=alpha, random_state=random_state)
        elif algorithm == "lasso":
            alpha = float(hyperparameters.get("alpha", 1.0))
            clf = Lasso(alpha=alpha, random_state=random_state)
        else: # linear_regression
            clf = LinearRegression()

    # Create end-to-end Pipeline
    model_pipeline = Pipeline(steps=[
        ('preprocessor', preprocessor),
        ('model', clf)
    ])

    # Fit pipeline strictly on X_train to prevent leakage
    model_pipeline.fit(X_train, y_train)

    # Predict on test
    y_pred = model_pipeline.predict(X_test)
    training_time_ms = round((time.time() - start_time) * 1000, 2)

    # Collect feature names after one-hot encoding
    transformed_feature_names = []
    if numeric_cols:
        transformed_feature_names.extend(numeric_cols)
    if categorical_cols:
        cat_encoder = model_pipeline.named_steps['preprocessor'].named_transformers_['cat'].named_steps['encoder']
        encoded_cats = cat_encoder.get_feature_names_out(categorical_cols).tolist()
        transformed_feature_names.extend(encoded_cats)

    # Feature importances or coefficients
    feature_importances = []
    fitted_model = model_pipeline.named_steps['model']
    raw_importances = None
    if hasattr(fitted_model, 'feature_importances_'):
        raw_importances = fitted_model.feature_importances_
    elif hasattr(fitted_model, 'coef_'):
        coef = fitted_model.coef_
        if coef.ndim > 1:
            raw_importances = np.mean(np.abs(coef), axis=0)
        else:
            raw_importances = np.abs(coef)

    if raw_importances is not None and len(raw_importances) == len(transformed_feature_names):
        norm_imp = raw_importances / (np.sum(raw_importances) + 1e-9)
        for name, score in zip(transformed_feature_names, norm_imp):
            feature_importances.append({
                "feature": name,
                "importance": round(float(score), 4),
                "percentage": round(float(score) * 100, 2)
            })
        feature_importances.sort(key=lambda x: x["importance"], reverse=True)

    metrics = {}
    charts_data = {}

    if is_classification:
        y_test_np = np.array(y_test)
        num_classes = len(classes_list)

        has_proba = hasattr(fitted_model, "predict_proba")
        y_proba = None
        if has_proba:
            y_proba = model_pipeline.predict_proba(X_test)

        acc = accuracy_score(y_test, y_pred)
        prec = precision_score(y_test, y_pred, average='weighted', zero_division=0)
        rec = recall_score(y_test, y_pred, average='weighted', zero_division=0)
        f1 = f1_score(y_test, y_pred, average='weighted', zero_division=0)
        f0_5 = ((1 + 0.5**2) * prec * rec) / ((0.5**2 * prec) + rec + 1e-9)
        f2 = ((1 + 2**2) * prec * rec) / ((2**2 * prec) + rec + 1e-9)

        metrics["ACCURACY"] = round(float(acc), 6)
        metrics["PRECISION"] = round(float(prec), 6)
        metrics["RECALL"] = round(float(rec), 6)
        metrics["F1"] = round(float(f1), 6)
        metrics["F0POINT5"] = round(float(f0_5), 6)
        metrics["F2"] = round(float(f2), 6)
        metrics["NOBS"] = float(len(X_test))
        metrics["TRAINING_TIME_MS"] = float(training_time_ms)

        # Confusion Matrix
        cm = confusion_matrix(y_test, y_pred)
        charts_data["confusion_matrix"] = {
            "classes": classes_list,
            "matrix": cm.tolist()
        }

        # Binary classification detailed curves & metrics
        if num_classes == 2 and y_proba is not None:
            pos_proba = y_proba[:, 1]
            try:
                auc_score = roc_auc_score(y_test, pos_proba)
                metrics["AUC"] = round(float(auc_score), 6)
                metrics["GINI"] = round(float(2 * auc_score - 1), 6)
            except Exception:
                metrics["AUC"] = 0.5
                metrics["GINI"] = 0.0

            try:
                auc_pr = average_precision_score(y_test, pos_proba)
                metrics["AUC-PR"] = round(float(auc_pr), 6)
            except Exception:
                metrics["AUC-PR"] = 0.0

            try:
                logloss = log_loss(y_test, y_proba)
                metrics["LOGLOSS"] = round(float(logloss), 6)
            except Exception:
                metrics["LOGLOSS"] = None

            # Brier Score / MSE on probabilities
            mse_val = mean_squared_error(y_test, pos_proba)
            metrics["MSE"] = round(float(mse_val), 6)
            metrics["RMSE"] = round(float(np.sqrt(mse_val)), 6)

            # Confusion matrix binary rates
            if cm.shape == (2, 2):
                tn, fp, fn, tp = cm.ravel()
                total_n = tn + fp
                total_p = fn + tp
                specificity = tn / total_n if total_n > 0 else 1.0
                sensitivity = tp / total_p if total_p > 0 else 1.0
                fallout = fp / total_n if total_n > 0 else 0.0
                missrate = fn / total_p if total_p > 0 else 0.0

                metrics["SPECIFICITY"] = round(float(specificity), 6)
                metrics["SENSITIVITY"] = round(float(sensitivity), 6)
                metrics["TNR"] = round(float(specificity), 6)
                metrics["TPR_METRIC"] = round(float(sensitivity), 6)
                metrics["FALLOUT"] = round(float(fallout), 6)
                metrics["FPR_METRIC"] = round(float(fallout), 6)
                metrics["FNR"] = round(float(missrate), 6)
                metrics["MISSRATE"] = round(float(missrate), 6)

            # ROC Curve points
            fpr, tpr, roc_thresholds = roc_curve(y_test, pos_proba)
            step = max(1, len(fpr) // 50)
            roc_points = [
                {"fpr": round(float(fpr[i]), 4), "tpr": round(float(tpr[i]), 4), "threshold": round(float(roc_thresholds[i]), 4)}
                for i in range(0, len(fpr), step)
            ]
            if roc_points[-1]["fpr"] < 1.0:
                roc_points.append({"fpr": 1.0, "tpr": 1.0, "threshold": 0.0})
            charts_data["roc_curve"] = roc_points

            # Precision-Recall Curve points
            pr_prec, pr_rec, pr_thresholds = precision_recall_curve(y_test, pos_proba)
            pr_step = max(1, len(pr_prec) // 50)
            pr_points = [
                {"recall": round(float(pr_rec[i]), 4), "precision": round(float(pr_prec[i]), 4)}
                for i in range(0, len(pr_prec), pr_step)
            ]
            charts_data["precision_recall_curve"] = pr_points

            # Threshold Metrics (sweep threshold from 0.05 to 0.95 in 0.05 increments)
            threshold_curves = []
            for th in np.linspace(0.05, 0.95, 19):
                pred_at_th = (pos_proba >= th).astype(int)
                t_cm = confusion_matrix(y_test, pred_at_th, labels=[0, 1])
                t_tn, t_fp, t_fn, t_tp = t_cm.ravel()
                t_acc = (t_tp + t_tn) / (t_tp + t_tn + t_fp + t_fn)
                t_prec = t_tp / (t_tp + t_fp) if (t_tp + t_fp) > 0 else 0
                t_rec = t_tp / (t_tp + t_fn) if (t_tp + t_fn) > 0 else 0
                t_f1 = (2 * t_prec * t_rec) / (t_prec + t_rec) if (t_prec + t_rec) > 0 else 0
                t_spec = t_tn / (t_tn + t_fp) if (t_tn + t_fp) > 0 else 0

                threshold_curves.append({
                    "threshold": round(float(th), 2),
                    "F1": round(float(t_f1), 4),
                    "ACCURACY": round(float(t_acc), 4),
                    "PRECISION": round(float(t_prec), 4),
                    "RECALL": round(float(t_rec), 4),
                    "SPECIFICITY": round(float(t_spec), 4)
                })
            charts_data["threshold_metrics"] = threshold_curves
        else:
            # Multi-class or no proba
            metrics["AUC"] = None
            metrics["AUC-PR"] = None
            metrics["LOGLOSS"] = None
            metrics["MSE"] = None
            metrics["RMSE"] = None
            metrics["GINI"] = None

    else:
        # Regression Metrics
        y_test_np = np.array(y_test)
        y_pred_np = np.array(y_pred)

        mae = mean_absolute_error(y_test, y_pred)
        mse = mean_squared_error(y_test, y_pred)
        rmse = np.sqrt(mse)
        r2 = r2_score(y_test, y_pred)
        exp_var = explained_variance_score(y_test, y_pred)
        # MAPE
        with np.errstate(divide='ignore', invalid='ignore'):
            mape = np.mean(np.abs((y_test_np - y_pred_np) / np.where(y_test_np == 0, 1e-9, y_test_np))) * 100

        metrics["MAE"] = round(float(mae), 4)
        metrics["MSE"] = round(float(mse), 4)
        metrics["RMSE"] = round(float(rmse), 4)
        metrics["R2"] = round(float(r2), 4)
        metrics["EXPLAINED_VARIANCE"] = round(float(exp_var), 4)
        metrics["MAPE"] = round(float(mape), 2)
        metrics["NOBS"] = float(len(X_test))
        metrics["TRAINING_TIME_MS"] = float(training_time_ms)

        # Regression Charts: Actual vs Predicted & Residuals (sampled 100 points)
        sample_indices = np.random.choice(len(y_test_np), min(100, len(y_test_np)), replace=False)
        actual_vs_pred = [
            {"actual": round(float(y_test_np[i]), 3), "predicted": round(float(y_pred_np[i]), 3), "residual": round(float(y_test_np[i] - y_pred_np[i]), 3)}
            for i in sample_indices
        ]
        charts_data["actual_vs_predicted"] = actual_vs_pred

    # Save model pipeline artifact
    model_id = str(uuid.uuid4())
    saved_model_path = os.path.join(MODELS_DIR, f"{model_id}.joblib")
    joblib.dump({
        "pipeline": model_pipeline,
        "feature_columns": feature_columns,
        "target_column": target_column,
        "task_type": task_type,
        "classes_list": classes_list,
        "algorithm": algorithm
    }, saved_model_path)

    # Generated model name
    timestamp_str = time.strftime("%Y%m%d_%H%M%S")
    auto_name = model_name or f"{algorithm.upper()}_{task_type[:3].upper()}_{timestamp_str}"

    return {
        "model_id": model_id,
        "name": auto_name,
        "algorithm": algorithm,
        "task_type": task_type,
        "target_column": target_column,
        "feature_columns": feature_columns,
        "hyperparameters": hyperparameters,
        "data_prep": {
            "test_size": test_size,
            "random_state": random_state,
            "numeric_imputer": numeric_imputer_strategy,
            "categorical_imputer": categorical_imputer_strategy,
            "scaler": scaler_type,
            "train_samples": len(X_train),
            "test_samples": len(X_test)
        },
        "metrics": metrics,
        "charts": charts_data,
        "feature_importances": feature_importances,
        "training_time_ms": training_time_ms,
        "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ")
    }

def run_prediction(model_id: str, input_features: dict):
    saved_model_path = os.path.join(MODELS_DIR, f"{model_id}.joblib")
    if not os.path.exists(saved_model_path):
        raise FileNotFoundError(f"Model artifact {model_id} not found.")

    saved_data = joblib.load(saved_model_path)
    pipeline = saved_data["pipeline"]
    feature_columns = saved_data["feature_columns"]
    task_type = saved_data["task_type"]
    classes_list = saved_data.get("classes_list")

    # Construct single-row DataFrame
    row_data = {}
    for col in feature_columns:
        val = input_features.get(col)
        # Parse numeric if possible
        if val is not None and isinstance(val, str):
            try:
                val = float(val) if '.' in val else int(val)
            except ValueError:
                pass
        row_data[col] = [val]

    input_df = pd.DataFrame(row_data)

    pred = pipeline.predict(input_df)[0]

    probabilities = None
    if task_type == "classification" and hasattr(pipeline.named_steps['model'], "predict_proba"):
        proba = pipeline.predict_proba(input_df)[0]
        probabilities = [
            {"class": classes_list[i] if classes_list and i < len(classes_list) else str(i), "probability": round(float(p), 4)}
            for i, p in enumerate(proba)
        ]

    predicted_label = str(pred)
    if classes_list and isinstance(pred, (int, np.integer)) and pred < len(classes_list):
        predicted_label = classes_list[pred]

    return {
        "prediction": predicted_label if task_type == "classification" else round(float(pred), 4),
        "task_type": task_type,
        "probabilities": probabilities,
        "input_features": input_features,
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ")
    }
