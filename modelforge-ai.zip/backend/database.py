import sqlite3
import json
import os
import time

DB_PATH = os.path.join(os.path.dirname(__file__), "experiments.db")

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    cursor = conn.cursor()

    # Datasets metadata table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS datasets (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        filename TEXT NOT NULL,
        row_count INTEGER,
        col_count INTEGER,
        file_size_bytes INTEGER,
        profile_json TEXT,
        is_sample INTEGER DEFAULT 0,
        created_at TEXT NOT NULL
    )
    """)

    # Models / Experiments table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS experiments (
        id TEXT PRIMARY KEY,
        dataset_id TEXT,
        model_name TEXT NOT NULL,
        algorithm TEXT NOT NULL,
        task_type TEXT NOT NULL,
        target_column TEXT NOT NULL,
        feature_columns TEXT NOT NULL,
        hyperparameters_json TEXT,
        data_prep_json TEXT,
        metrics_json TEXT NOT NULL,
        charts_json TEXT,
        feature_importances_json TEXT,
        training_time_ms REAL,
        is_best INTEGER DEFAULT 0,
        is_deployed INTEGER DEFAULT 0,
        created_at TEXT NOT NULL,
        FOREIGN KEY (dataset_id) REFERENCES datasets (id)
    )
    """)

    # Predictions log table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS predictions (
        id TEXT PRIMARY KEY,
        experiment_id TEXT NOT NULL,
        input_data_json TEXT NOT NULL,
        prediction_output TEXT NOT NULL,
        probabilities_json TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY (experiment_id) REFERENCES experiments (id)
    )
    """)

    conn.commit()
    conn.close()

def save_dataset_meta(dataset_id: str, name: str, filename: str, row_count: int, col_count: int, file_size_bytes: int, profile: dict, is_sample: bool = False):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT OR REPLACE INTO datasets (id, name, filename, row_count, col_count, file_size_bytes, profile_json, is_sample, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (dataset_id, name, filename, row_count, col_count, file_size_bytes, json.dumps(profile), 1 if is_sample else 0, time.strftime("%Y-%m-%dT%H:%M:%SZ")))
    conn.commit()
    conn.close()

def list_datasets():
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT id, name, filename, row_count, col_count, file_size_bytes, is_sample, created_at FROM datasets ORDER BY created_at DESC")
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]

def get_dataset(dataset_id: str):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM datasets WHERE id = ?", (dataset_id,))
    row = cursor.fetchone()
    conn.close()
    if row:
        d = dict(row)
        if d.get("profile_json"):
            d["profile"] = json.loads(d["profile_json"])
        return d
    return None

def save_experiment(exp_data: dict, dataset_id: str = None):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO experiments (
            id, dataset_id, model_name, algorithm, task_type, target_column,
            feature_columns, hyperparameters_json, data_prep_json, metrics_json,
            charts_json, feature_importances_json, training_time_ms, is_best, is_deployed, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        exp_data["model_id"],
        dataset_id,
        exp_data["name"],
        exp_data["algorithm"],
        exp_data["task_type"],
        exp_data["target_column"],
        json.dumps(exp_data["feature_columns"]),
        json.dumps(exp_data.get("hyperparameters", {})),
        json.dumps(exp_data.get("data_prep", {})),
        json.dumps(exp_data["metrics"]),
        json.dumps(exp_data.get("charts", {})),
        json.dumps(exp_data.get("feature_importances", [])),
        exp_data.get("training_time_ms", 0.0),
        0,
        0,
        exp_data.get("created_at", time.strftime("%Y-%m-%dT%H:%M:%SZ"))
    ))
    conn.commit()
    conn.close()

def list_experiments(dataset_id: str = None):
    conn = get_db()
    cursor = conn.cursor()
    if dataset_id:
        cursor.execute("SELECT * FROM experiments WHERE dataset_id = ? ORDER BY created_at DESC", (dataset_id,))
    else:
        cursor.execute("SELECT * FROM experiments ORDER BY created_at DESC")
    rows = cursor.fetchall()
    conn.close()
    result = []
    for r in rows:
        item = dict(r)
        item["feature_columns"] = json.loads(item["feature_columns"]) if item["feature_columns"] else []
        item["hyperparameters"] = json.loads(item["hyperparameters_json"]) if item["hyperparameters_json"] else {}
        item["data_prep"] = json.loads(item["data_prep_json"]) if item["data_prep_json"] else {}
        item["metrics"] = json.loads(item["metrics_json"]) if item["metrics_json"] else {}
        item["charts"] = json.loads(item["charts_json"]) if item["charts_json"] else {}
        item["feature_importances"] = json.loads(item["feature_importances_json"]) if item["feature_importances_json"] else []
        result.append(item)
    return result

def get_experiment(experiment_id: str):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM experiments WHERE id = ?", (experiment_id,))
    row = cursor.fetchone()
    conn.close()
    if row:
        item = dict(row)
        item["feature_columns"] = json.loads(item["feature_columns"]) if item["feature_columns"] else []
        item["hyperparameters"] = json.loads(item["hyperparameters_json"]) if item["hyperparameters_json"] else {}
        item["data_prep"] = json.loads(item["data_prep_json"]) if item["data_prep_json"] else {}
        item["metrics"] = json.loads(item["metrics_json"]) if item["metrics_json"] else {}
        item["charts"] = json.loads(item["charts_json"]) if item["charts_json"] else {}
        item["feature_importances"] = json.loads(item["feature_importances_json"]) if item["feature_importances_json"] else []
        return item
    return None

def set_best_model(experiment_id: str):
    conn = get_db()
    cursor = conn.cursor()
    # Unset other models for the same target / dataset if needed
    cursor.execute("UPDATE experiments SET is_best = 0")
    cursor.execute("UPDATE experiments SET is_best = 1 WHERE id = ?", (experiment_id,))
    conn.commit()
    conn.close()

def toggle_deployment(experiment_id: str):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT is_deployed FROM experiments WHERE id = ?", (experiment_id,))
    row = cursor.fetchone()
    if row:
        new_state = 0 if row["is_deployed"] == 1 else 1
        cursor.execute("UPDATE experiments SET is_deployed = ? WHERE id = ?", (new_state, experiment_id))
        conn.commit()
        conn.close()
        return bool(new_state)
    conn.close()
    return False

def save_prediction(prediction_id: str, experiment_id: str, input_data: dict, prediction_output: str, probabilities: list = None):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO predictions (id, experiment_id, input_data_json, prediction_output, probabilities_json, created_at)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (prediction_id, experiment_id, json.dumps(input_data), str(prediction_output), json.dumps(probabilities) if probabilities else None, time.strftime("%Y-%m-%dT%H:%M:%SZ")))
    conn.commit()
    conn.close()

def list_predictions(experiment_id: str = None):
    conn = get_db()
    cursor = conn.cursor()
    if experiment_id:
        cursor.execute("SELECT * FROM predictions WHERE experiment_id = ? ORDER BY created_at DESC LIMIT 50", (experiment_id,))
    else:
        cursor.execute("SELECT * FROM predictions ORDER BY created_at DESC LIMIT 50")
    rows = cursor.fetchall()
    conn.close()
    res = []
    for r in rows:
        item = dict(r)
        item["input_data"] = json.loads(item["input_data_json"]) if item["input_data_json"] else {}
        item["probabilities"] = json.loads(item["probabilities_json"]) if item["probabilities_json"] else None
        res.append(item)
    return res
