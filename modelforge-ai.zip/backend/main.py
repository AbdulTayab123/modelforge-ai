import io
import os
import shutil
import uuid
import json
import pandas as pd
from fastapi import FastAPI, UploadFile, File, HTTPException, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse, PlainTextResponse
from pydantic import BaseModel
from typing import List, Optional, Dict, Any

from backend.database import (
    init_db, save_dataset_meta, list_datasets, get_dataset,
    save_experiment, list_experiments, get_experiment,
    set_best_model, toggle_deployment, save_prediction, list_predictions
)
from backend.ml_engine import profile_dataset, train_and_evaluate_model, run_prediction, MODELS_DIR
from backend.sample_datasets import generate_sample_datasets, DATASETS_DIR

app = FastAPI(
    title="ModelForge AI Engine",
    description="Full-stack Machine Learning Studio powered by FastAPI, Pandas, and Scikit-learn",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

UPLOAD_DIR = os.path.join(os.path.dirname(__file__), "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

# Startup event to initialize DB and seed initial sample datasets and pre-trained demonstration experiment
@app.on_event("startup")
def startup_event():
    init_db()
    sample_files = generate_sample_datasets()

    # Seed sample datasets in DB if not already present
    existing = {d["name"]: d for d in list_datasets()}

    churn_file = sample_files["customer_churn"]
    if "Telco Customer Churn" not in existing and os.path.exists(churn_file):
        df_churn = pd.read_csv(churn_file)
        churn_profile = profile_dataset(df_churn)
        ds_id = "sample_churn_5000"
        save_dataset_meta(
            dataset_id=ds_id,
            name="Telco Customer Churn",
            filename="customer_churn.csv",
            row_count=len(df_churn),
            col_count=len(df_churn.columns),
            file_size_bytes=os.path.getsize(churn_file),
            profile=churn_profile,
            is_sample=True
        )

        # Train initial reference model to match the screenshot!
        # In screenshot: GBM_2_AutoML_1_20260225_183713, Algorithm: gbm
        try:
            exp_res = train_and_evaluate_model(
                df=df_churn,
                target_column="Churn",
                feature_columns=["SeniorCitizen", "Partner", "Dependents", "Tenure", "Contract", "InternetService", "OnlineSecurity", "TechSupport", "PaymentMethod", "MonthlyCharges", "TotalCharges"],
                task_type="classification",
                algorithm="gbm",
                hyperparameters={"n_estimators": 100, "learning_rate": 0.1, "max_depth": 3},
                model_name="GBM_2_AutoML_1_20260225_183713"
            )
            save_experiment(exp_res, dataset_id=ds_id)
            set_best_model(exp_res["model_id"])
        except Exception as e:
            print("Error pre-training demo model:", e)

    housing_file = sample_files["california_housing"]
    if "California Housing Prices" not in existing and os.path.exists(housing_file):
        df_house = pd.read_csv(housing_file)
        house_profile = profile_dataset(df_house)
        save_dataset_meta(
            dataset_id="sample_housing_3000",
            name="California Housing Prices",
            filename="california_housing.csv",
            row_count=len(df_house),
            col_count=len(df_house.columns),
            file_size_bytes=os.path.getsize(housing_file),
            profile=house_profile,
            is_sample=True
        )

    diabetes_file = sample_files["diabetes_risk"]
    if "Diabetes Medical Risk" not in existing and os.path.exists(diabetes_file):
        df_diab = pd.read_csv(diabetes_file)
        diab_profile = profile_dataset(df_diab)
        save_dataset_meta(
            dataset_id="sample_diabetes_1500",
            name="Diabetes Medical Risk",
            filename="diabetes_risk.csv",
            row_count=len(df_diab),
            col_count=len(df_diab.columns),
            file_size_bytes=os.path.getsize(diabetes_file),
            profile=diab_profile,
            is_sample=True
        )

@app.get("/api/health")
def health():
    import sklearn
    import numpy
    return {
        "status": "healthy",
        "app": "ModelForge AI",
        "python": "3.11",
        "scikit_learn_version": sklearn.__version__,
        "numpy_version": numpy.__version__,
        "pandas_version": pd.__version__
    }

@app.get("/api/datasets")
def get_datasets():
    return list_datasets()

@app.get("/api/datasets/{dataset_id}")
def get_dataset_by_id(dataset_id: str):
    ds = get_dataset(dataset_id)
    if not ds:
        raise HTTPException(status_code=404, detail="Dataset not found")
    return ds

@app.post("/api/datasets/upload")
async def upload_dataset(file: UploadFile = File(...)):
    if not file.filename.endswith(".csv"):
        raise HTTPException(status_code=400, detail="Only CSV files are supported.")

    content = await file.read()
    if len(content) > 50 * 1024 * 1024:
        raise HTTPException(status_code=400, detail="File too large (max 50MB).")

    # Safe sanitized filename
    safe_id = str(uuid.uuid4())
    stored_path = os.path.join(UPLOAD_DIR, f"{safe_id}.csv")
    with open(stored_path, "wb") as f:
        f.write(content)

    try:
        df = pd.read_csv(stored_path)
    except Exception as e:
        if os.path.exists(stored_path):
            os.remove(stored_path)
        raise HTTPException(status_code=400, detail=f"Failed to parse CSV: {str(e)}")

    if len(df) == 0:
        if os.path.exists(stored_path):
            os.remove(stored_path)
        raise HTTPException(status_code=400, detail="Uploaded CSV file is empty.")

    profile = profile_dataset(df)
    save_dataset_meta(
        dataset_id=safe_id,
        name=os.path.splitext(file.filename)[0],
        filename=file.filename,
        row_count=len(df),
        col_count=len(df.columns),
        file_size_bytes=len(content),
        profile=profile,
        is_sample=False
    )

    return get_dataset(safe_id)

class TrainRequest(BaseModel):
    dataset_id: str
    target_column: str
    feature_columns: List[str]
    task_type: str # "classification" or "regression"
    algorithm: str # "gbm", "random_forest", "logistic_regression", "linear_regression", "decision_tree", "ridge", "lasso"
    hyperparameters: Optional[Dict[str, Any]] = None
    test_size: Optional[float] = 0.2
    random_state: Optional[int] = 42
    numeric_imputer: Optional[str] = "median"
    categorical_imputer: Optional[str] = "most_frequent"
    scaler: Optional[str] = "standard"
    model_name: Optional[str] = None

@app.post("/api/train")
def train_model(req: TrainRequest):
    ds = get_dataset(req.dataset_id)
    if not ds:
        raise HTTPException(status_code=404, detail="Dataset not found")

    # Locate CSV file
    file_path = None
    if ds.get("is_sample"):
        sample_path = os.path.join(DATASETS_DIR, ds["filename"])
        if os.path.exists(sample_path):
            file_path = sample_path
    if not file_path:
        uploaded_path = os.path.join(UPLOAD_DIR, f"{req.dataset_id}.csv")
        if os.path.exists(uploaded_path):
            file_path = uploaded_path

    if not file_path or not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="Dataset CSV data file not found on disk.")

    try:
        df = pd.read_csv(file_path)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to read dataset: {str(e)}")

    if req.target_column not in df.columns:
        raise HTTPException(status_code=400, detail=f"Target column '{req.target_column}' does not exist.")

    for col in req.feature_columns:
        if col not in df.columns:
            raise HTTPException(status_code=400, detail=f"Feature column '{col}' does not exist.")

    try:
        exp_result = train_and_evaluate_model(
            df=df,
            target_column=req.target_column,
            feature_columns=req.feature_columns,
            task_type=req.task_type,
            algorithm=req.algorithm,
            hyperparameters=req.hyperparameters,
            test_size=req.test_size or 0.2,
            random_state=req.random_state or 42,
            numeric_imputer_strategy=req.numeric_imputer or "median",
            categorical_imputer_strategy=req.categorical_imputer or "most_frequent",
            scaler_type=req.scaler or "standard",
            model_name=req.model_name
        )
        save_experiment(exp_result, dataset_id=req.dataset_id)
        return exp_result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Training failed: {str(e)}")

@app.get("/api/experiments")
def get_all_experiments(dataset_id: Optional[str] = None):
    return list_experiments(dataset_id)

@app.get("/api/experiments/{experiment_id}")
def get_experiment_by_id(experiment_id: str):
    exp = get_experiment(experiment_id)
    if not exp:
        raise HTTPException(status_code=404, detail="Experiment not found")
    return exp

@app.post("/api/experiments/{experiment_id}/set_best")
def mark_best_model(experiment_id: str):
    exp = get_experiment(experiment_id)
    if not exp:
        raise HTTPException(status_code=404, detail="Experiment not found")
    set_best_model(experiment_id)
    return {"status": "ok", "experiment_id": experiment_id, "is_best": True}

@app.post("/api/experiments/{experiment_id}/deploy")
def deploy_model(experiment_id: str):
    exp = get_experiment(experiment_id)
    if not exp:
        raise HTTPException(status_code=404, detail="Experiment not found")
    new_state = toggle_deployment(experiment_id)
    return {"status": "ok", "experiment_id": experiment_id, "is_deployed": new_state}

class PredictRequest(BaseModel):
    features: Dict[str, Any]

@app.post("/api/predict/{experiment_id}")
def predict(experiment_id: str, req: PredictRequest):
    exp = get_experiment(experiment_id)
    if not exp:
        raise HTTPException(status_code=404, detail="Experiment not found")

    try:
        result = run_prediction(experiment_id, req.features)
        pred_id = str(uuid.uuid4())
        save_prediction(
            prediction_id=pred_id,
            experiment_id=experiment_id,
            input_data=req.features,
            prediction_output=str(result["prediction"]),
            probabilities=result.get("probabilities")
        )
        result["prediction_id"] = pred_id
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Prediction error: {str(e)}")

@app.get("/api/experiments/{experiment_id}/download")
def download_model_artifact(experiment_id: str):
    model_path = os.path.join(MODELS_DIR, f"{experiment_id}.joblib")
    if not os.path.exists(model_path):
        raise HTTPException(status_code=404, detail="Model binary artifact not found.")
    return FileResponse(
        model_path,
        media_type="application/octet-stream",
        filename=f"modelforge_{experiment_id}.joblib"
    )

@app.get("/api/experiments/{experiment_id}/notebook")
def download_notebook(experiment_id: str):
    exp = get_experiment(experiment_id)
    if not exp:
        raise HTTPException(status_code=404, detail="Experiment not found")

    dataset_name = "data.csv"
    ds = get_dataset(exp.get("dataset_id")) if exp.get("dataset_id") else None
    if ds:
        dataset_name = ds.get("filename", "data.csv")

    code_script = f"""# =======================================================
# ModelForge AI - Automated Reproducible Experiment Script
# Model Name: {exp['model_name']}
# Algorithm: {exp['algorithm']} ({exp['task_type']})
# Generated at: {exp['created_at']}
# =======================================================

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
"""

    if exp['task_type'] == 'classification':
        code_script += """from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix
"""
        if exp['algorithm'] == 'gbm':
            code_script += "from sklearn.ensemble import GradientBoostingClassifier as Estimator\n"
        elif exp['algorithm'] == 'random_forest':
            code_script += "from sklearn.ensemble import RandomForestClassifier as Estimator\n"
        elif exp['algorithm'] == 'decision_tree':
            code_script += "from sklearn.tree import DecisionTreeClassifier as Estimator\n"
        else:
            code_script += "from sklearn.linear_model import LogisticRegression as Estimator\n"
    else:
        code_script += """from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
"""
        if exp['algorithm'] == 'gbm':
            code_script += "from sklearn.ensemble import GradientBoostingRegressor as Estimator\n"
        elif exp['algorithm'] == 'random_forest':
            code_script += "from sklearn.ensemble import RandomForestRegressor as Estimator\n"
        elif exp['algorithm'] == 'decision_tree':
            code_script += "from sklearn.tree import DecisionTreeRegressor as Estimator\n"
        else:
            code_script += "from sklearn.linear_model import LinearRegression as Estimator\n"

    features_repr = json.dumps(exp['feature_columns'])
    target_repr = json.dumps(exp['target_column'])
    params_repr = json.dumps(exp['hyperparameters'])

    code_script += f"""
# 1. Load Data
df = pd.read_csv('{dataset_name}')
target = {target_repr}
features = {features_repr}

clean_df = df.dropna(subset=[target]).copy()
X = clean_df[features]
y = clean_df[target]

# 2. Identify Column Types
numeric_cols = [c for c in features if pd.api.types.is_numeric_dtype(X[c])]
categorical_cols = [c for c in features if c not in numeric_cols]

# 3. Build Preprocessing Transformers
preprocessor = ColumnTransformer(transformers=[
    ('num', Pipeline([
        ('imputer', SimpleImputer(strategy='{exp["data_prep"].get("numeric_imputer", "median")}')),
        ('scaler', StandardScaler())
    ]), numeric_cols),
    ('cat', Pipeline([
        ('imputer', SimpleImputer(strategy='{exp["data_prep"].get("categorical_imputer", "most_frequent")}')),
        ('encoder', OneHotEncoder(handle_unknown='ignore', sparse_output=False))
    ]), categorical_cols)
])

# 4. Initialize Pipeline
model = Estimator(**{params_repr})
pipeline = Pipeline([
    ('preprocessor', preprocessor),
    ('model', model)
])

# 5. Train/Test Split & Fit
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size={exp['data_prep'].get('test_size', 0.2)}, random_state={exp['data_prep'].get('random_state', 42)}
)

pipeline.fit(X_train, y_train)
y_pred = pipeline.predict(X_test)

# 6. Evaluation
print("Model Evaluation:")
"""
    if exp['task_type'] == 'classification':
        code_script += """print("Accuracy:", accuracy_score(y_test, y_pred))
print("F1 Score:", f1_score(y_test, y_pred, average='weighted', zero_division=0))
print("Confusion Matrix:\\n", confusion_matrix(y_test, y_pred))
"""
    else:
        code_script += """print("MAE:", mean_absolute_error(y_test, y_pred))
print("RMSE:", np.sqrt(mean_squared_error(y_test, y_pred)))
print("R2 Score:", r2_score(y_test, y_pred))
"""

    return PlainTextResponse(code_script, media_type="text/x-python", headers={"Content-Disposition": f"attachment; filename=modelforge_{exp['model_name']}.py"})

@app.get("/api/predictions")
def get_predictions(experiment_id: Optional[str] = None):
    return list_predictions(experiment_id)
